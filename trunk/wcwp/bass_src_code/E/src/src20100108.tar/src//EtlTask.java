import java.io.FileWriter;

class EtlTask implements Runnable {
	private String strSQL;
	private String strArea;
	private String strTaskID;
	private String strModule;
	private String strCycle;

	public EtlTask(String strSQL, String strArea, String strTaskID,
			String strModule, String strCycle) {

		this.strSQL = strSQL;
		this.strArea = strArea;
		this.strTaskID = strTaskID;
		this.strModule = strModule;
		this.strCycle = strCycle;
	}

	public void run() {
		// ��ȡ�ӿ����ò���
		ETLWrite ew = new ETLWrite();
		strSQL = strSQL.replaceAll("\\$FEE_AREA\\$", strArea);
		System.out.println("strSQL==============>" + strSQL);
		System.out.println("strArea=========>" + strArea);
		int cnt = ew.writeInterfaceFile(strSQL, strArea, strTaskID, strModule,
				strCycle);
		TaskConfig tc = new TaskConfig(strTaskID);
		synchronized(TaskConfig.class) {
			tc.setProperties("CNT"+strArea, String.valueOf(cnt));
		}
		
		
		
	}
}
