#ifndef _cmpublic_dbH
#define _cmpublic_dbH

#ifndef __ORACLECLASS
#define __ORACLECLASS
#endif

#ifdef  __ORACLECLASS
#include <oci.h>
#endif

#include "c_database.h"
#include "c_table.h"
#include "c_query.h"

extern TCDatabase DatabaseMain;

#endif


