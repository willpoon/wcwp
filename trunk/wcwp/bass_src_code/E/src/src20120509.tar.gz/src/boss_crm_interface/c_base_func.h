//---------------------------------------------------------------------------

#ifndef c_base_funcH
#define c_base_funcH
//---------------------------------------------------------------------------

TCString RelativeMonth(TCString sMonth,long lAdustValue);
TCString RelativeDay(TCString sDay,long lAdustValue);
TCString GetNextValue(TCString sStyle,TCString sValue,long lAdustValue);
#endif


