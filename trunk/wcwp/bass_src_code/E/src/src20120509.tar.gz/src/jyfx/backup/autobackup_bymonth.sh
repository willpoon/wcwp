#!/bin/sh
#author:lgk
#date: 2006/12/18

while [ true ]
do
	ls *.END *.AVL.Z|cut -c7-12|sort -u|awk '{print "mkdir "$1";mv *"$1"*.* "$1}'|sh
	sleep 1800
done