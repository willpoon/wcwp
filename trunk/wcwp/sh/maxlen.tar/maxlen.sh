awk -f $shroot/maxlen.awk -v v_del="$2" $1 
