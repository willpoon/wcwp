aa=`get_kpi.sh 20070311 2`
echo $aa