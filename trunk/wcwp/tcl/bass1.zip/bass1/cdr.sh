./e_transform -s ../cdr_call_sample.txt -e ../tmp -o cdr_call_sample -c 999 -t 2007-03-01 -p 2007031101 -u 1 -v 1
