./e_clean -o FILE_29 -e ../tmp -c 999 -p 20070326 -t 2007-03-01 -u 0 -v 0 -s ../cdr_call_sample.txt -k 1
