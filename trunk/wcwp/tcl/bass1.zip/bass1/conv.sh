e_convert -o 21001_4 -s /DB2/bass1/data_dir/semidata/ds_20070311_21001.bass2 -r /DB2/bass1/data_dir/tempdata/s_89000_20070311_21001_00 -c 999 -t 2007-03-11 -p 20070311 -u 9999 -v 9999
