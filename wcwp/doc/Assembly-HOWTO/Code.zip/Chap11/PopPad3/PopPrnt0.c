/*---------------------------------------------------------------
   POPPRNT0.C -- Popup Editor Printing Functions (dummy version)
  ---------------------------------------------------------------*/

#include <windows.h>

BOOL PopPrntPrintFile (HINSTANCE hInst, HWND hwnd, HWND hwndEdit,
                       PTSTR pstrTitleName)
{
     return FALSE ;
}
