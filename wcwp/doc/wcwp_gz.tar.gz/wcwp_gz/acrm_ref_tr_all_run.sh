nohup db2 -tvf acrm_ref_tr_all_run.sql>out_acrm_ref_tr_all_run.sql.out 2>&1 &
. ~/panzw/.pz_settings
exit
