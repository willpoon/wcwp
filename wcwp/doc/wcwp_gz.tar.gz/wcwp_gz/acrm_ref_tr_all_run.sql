CHANGE ISOLATION TO UR;
CONNECT TO acrm USER zhengfm USING tds2008;
SET SCHEMA KF2;
EXPORT TO /home/zhengfm/panzw/outdata/acrm_ref_tr_all.csv.txt OF DEL 
modified by nochardel 
striplzeros 
decplusblank 
select 		
			rtrim(tabschema)
	||'.'||		tabname
	,		card
	,		colcount
	,		npages
	,		fpages
	,		create_time
	,		stats_time
	,		tbspace 
from 		syscat.tables
order by 1
with ur;


terminate;
