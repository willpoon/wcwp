select          
                        rtrim(tabschema)
        ||'.'||         tabname
        ,               card
        ,               colcount
        ,               npages
        ,               fpages
        ,               create_time
        ,               stats_time
        ,               tbspace 
from            syscat.tables
order by 1
with ur;
