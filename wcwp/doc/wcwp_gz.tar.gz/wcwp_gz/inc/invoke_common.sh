. $PZW_INC/common.ksh
