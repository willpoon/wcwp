ora_exec_sql(){
echo `date +%m-%d:%H:%M:%S`
sqlplus -s zhengfengmei/oracle123@gzdm<<EOF
set echo off
alter session force parallel query parallel 15;
alter session force parallel dml parallel 15;
set autocommit on
set pagesize 0
set heading on
set echo on
$1
EOF
if [ $? -gt 0 ];then
echo $? sql error
fi
echo `date +%m-%d:%H:%M:%S`
}
sql="
desc aa
"
ora_exec_sql "$sql"

