sqlplus -s zhengfengmei/oracle123@gzdm<<EOF
set echo off
alter session force parallel query parallel 15;
alter session force parallel dml parallel 15;
set autocommit on
set pagesize 0
set heading on
set echo on
$1
EOF
echo $?
