#!/usr/bin/perl
use Proc::Daemon;
Proc::Daemon::Init;
open LOG, ">/home/yourname/log";
print LOG "Process Id is $$.\n";
close LOG;
sleep 100;
