. $PZW_INC/common.ksh 
sch1=A
sch2=B
sch3=C
echo SELECT
for fields in `descf $1|sed -e 's/,//g`
do 
echo "		,"${sch1}.${fields}
done
for fields in `descf $2|sed -e 's/,//g`
do 
echo "		,"${sch2}.${fields}
done
for fields in `descf $3|sed -e 's/,//g`
do 
echo "		,"${sch3}.${fields}
done
echo FROM
echo      "		"$1 ${sch1}|tr [a-z] [A-Z]
echo JOIN
echo      "		"$2 ${sch2}|tr [a-z] [A-Z]
echo ON
echo       "		"${sch1}.USR_NBR \= ${sch2}.USR_NBR
echo JOIN
echo      "		"$3 ${sch3}|tr [a-z] [A-Z]
echo ON
echo       "		"${sch1}.USR_NBR \= ${sch3}.USR_NBR
echo \;
echo " "
echo " "

