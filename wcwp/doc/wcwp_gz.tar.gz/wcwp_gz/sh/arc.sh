if [ $# -eq 1 ] ;then 
tar -cvf $1.tar rs_*$1*.txt
gzip -9 $1*.tar
else 
echo "arc <sno>"
exit 1
fi
