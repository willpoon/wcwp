if [ $# -ne 3 ] ; then 
echo "usage: chdel <filename> <fs> <ofs>"
exit 1 
fi
awk -f $shroot/chdel.awk -v v_fs_del="$2" -v v_ofs_del="$3" $1 
