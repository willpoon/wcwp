echo ""
echo "DROP INDEX  IDX_$1;"
echo "CREATE INDEX IDX_$1 ON $2($3);"
echo ""
