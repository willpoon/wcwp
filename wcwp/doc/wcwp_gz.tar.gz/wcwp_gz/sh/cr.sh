SKM=CHENLIFENG
#SKM="\${SKM}"
echo " "
echo " "
echo "DROP TABLE TMP_PZW_$1 PURGE;"|tr '[A-Z]'  '[a-z]' >>.cr.tmp
echo CREATE TABLE TMP_PZW_$1|tr '[A-Z]'  '[a-z]' >>.cr.tmp
echo \( >>.cr.tmp
echo "rn	number">>.cr.tmp
echo ",usr_nbr	varchar2(11)">>.cr.tmp
echo \)\;>>.cr.tmp
echo " ">>.cr.tmp
echo "!load.sh tmp_pzw_$1 nbr .txt">>.cr.tmp
echo " ">>.cr.tmp
echo "--TRUNCATE TABLE  TMP_PZW_$1;"|tr '[A-Z]'  '[a-z]'>>.cr.tmp
echo " ">>.cr.tmp
echo " ">>.cr.tmp
echo "delete from TMP_PZW_$1 where month = ;"|tr '[A-Z]'  '[a-z]' >>.cr.tmp
echo " ">>.cr.tmp
echo "INSERT INTO TMP_PZW_$1"|tr '[A-Z]'  '[a-z]'>>.cr.tmp
echo "SELECT"|tr '[A-Z]'  '[a-z]'>>.cr.tmp
echo "DISTINCT" >>.cr.tmp
echo " ">>.cr.tmp
echo " ">>.cr.tmp
echo " ">>.cr.tmp
echo "DROP TABLE TMP_PZW_$1 PURGE;"|tr '[A-Z]'  '[a-z]' >>.cr.tmp
echo create table TMP_PZW_$1>>.cr.tmp
echo " as" >>.cr.tmp
echo select >>.cr.tmp
echo "DISTINCT" >>.cr.tmp
echo " "
cat .cr.tmp|tr '[A-Z]'  '[a-z]'
echo " "
echo " "
rm .cr.tmp
