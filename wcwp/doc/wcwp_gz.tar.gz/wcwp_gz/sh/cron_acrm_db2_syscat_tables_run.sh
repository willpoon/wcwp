nohup db2 -tvf sql_cron_acrm_db2_syscat_tables_run.sql>out_sql_cron_acrm_db2_syscat_tables_run.out 2>&1 &
. ~/panzw/.pz_settings
exit
