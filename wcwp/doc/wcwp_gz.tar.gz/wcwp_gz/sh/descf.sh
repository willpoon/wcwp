. $PZW_INC/common.ksh
desc="
desc $1;
"
ora_exec_sql "$desc"|sed -e '/^$/d'|sed -e 's/NOT//g'|sed -e 's/NULL//g'|awk 'BEGIN{FS=" ";OFS=","} {printf "%-30s \n", ","$1}'|sed -e '1,3d;$d'

