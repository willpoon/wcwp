. $PZW_INC/common.ksh
if [ $# -ne 2 ];then 
echo "usage:exdata <indata> <del>"
exit 1
fi
maxlen $1 $2
minlen $1 $2
sedm $1
maxlen $1.s $2
minlen $1.s $2
wc -l $1
head $1*
tail $1*

wc -l $1*
