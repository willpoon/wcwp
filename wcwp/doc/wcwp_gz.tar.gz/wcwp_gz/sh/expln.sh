db2expln -d acrm -u zhengfm itc@gmcc -z ";" -t -g -f $1

