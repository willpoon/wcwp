
select 
USR_NBR               
,VPMN_NO               
,VPMN_NAM              
,CLI_DELEGATE          
,CORP_SIZE_TYP_NAM     
,INNET_DT              
,BRND_CD               
,CURRMO_AMT_FEE_11     
,CURRMO_AMT_FEE_12     
,CURRMO_AMT_FEE_01                
from KT_PZW_AB090227020_GRP_RS2 order by vpmn_no;

