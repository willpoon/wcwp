. $cfgroot/cfg/.pz*se*
l211
if [ -e ~/panzw/.ftp_tmp/step1.tbs.txt ]
then 
sedm ~/panzw/.ftp_tmp/step1.tbs.txt
mv ~/panzw/.ftp_tmp/step1.tbs.txt.s  .
else 
echo file step1.tbs.txt not exists
fi

######################

if [ -e ~/panzw/.ftp_tmp/step2.run.txt ]
then
sedm ~/panzw/.ftp_tmp/step2.run.txt
mv ~/panzw/.ftp_tmp/step2.run.txt.s .
rm -rf ~/panzw/.ftp_tmp/step*
else 
echo file step2.tbs.txt not exists 
fi

