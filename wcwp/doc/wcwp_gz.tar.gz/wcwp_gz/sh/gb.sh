#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
dist_field="brnd_cd"
else 
dist_field=$2
fi
select_distinct="
set linesize 20000;
select $2, count(0) 
from $1 
group by $2 order by 1
;
"
echo " "
echo " "
echo  "select $2, count(0) from $1 group by $2 order by 1 ;"
ora_exec_sql "$select_distinct"|sed -e '/ession/d'|sed -e '/^$/d'

