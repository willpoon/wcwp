echo head `pwd`/*$1*
echo tail `pwd`/*$1*
echo wc -l `pwd`/*$1*

