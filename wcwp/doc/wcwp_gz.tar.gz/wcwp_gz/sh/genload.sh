if [ $# -ne 1 ] ; then
echo "genload <full_ctl_file>"
exit 1 
fi
echo " "
echo " "
echo "ctl=\""
cat $1
echo "\""
echo "echo \"\$ctl\">$1"
echo " "
cat load_*.sh

echo " "
echo " "

