alias getdat='echo \$ getdat| ftp 10.244.28.4'
getdat
mv ~/panzw/.ftp_tmp/*.dat .

