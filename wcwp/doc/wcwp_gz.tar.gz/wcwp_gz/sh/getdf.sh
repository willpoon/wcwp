join -1 2,2 -2 1,1 -o 1.1,2.1,2.2  a.txt b.txt|sort -n|awk 'BEGIN{FS=",";OFS=","}{print ","$2}'|awk 'BEGIN{FS="\t";OFS="\t"}{print $1,$2}'
