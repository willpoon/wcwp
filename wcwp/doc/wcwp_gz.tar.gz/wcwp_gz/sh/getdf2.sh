if [ $# -ne 1 ];then
echo "usage: gdf <field_list>"
echo "and make sure you having genenate the tbs_name.txt "
exit 1
fi
#give every field a sequence number.
cat <<EEE|sed -e 's/[A-Z]\.//g;s/ *//g'|awk 'BEGIN{FS=",";OFS=","}{print NR"\t",$2}'|sort  -k2,2 > a.txt
$1
EEE
cat <<EEE|sed -e 's/[A-Z]\.//g;s/ *//g'|awk 'BEGIN{FS=",";OFS=","}{print NR"\t",$2}'|sort  -k2,2 
$1
EEE
echo "want to see  sorted result? chk a.txt"

# get field name  and length defination. and then output to b.txt , join with a.txt in next step.
if [ $# -ne 1 ];then 
echo "usage: jfd <field_list_to_select>" 
exit 1
fi
echo " "
echo " "
fields=`echo $1|sed -e 's/[A-Z]\.//g;s/ *//g;s/,/|/g'|sed -e 's/|//1'`
echo "'"$fields"'"
echo ""
echo ""
#grep -iE $fields tbs_name.txt
grep -iE $fields tbs_name.txt|sort|uniq>b.txt
echo "want to see matching result ? chk b.txt"
echo " "
echo " "
echo "this is the final result you get: "
echo " "
echo " "
#get final result 
#join -1 2,2 -2 1,1 -o 1.1,2.1,2.2  a.txt b.txt|sort -n|awk 'BEGIN{FS=",";OFS=","}{print ","$2}'|awk 'BEGIN{FS="\t";OFS="\t"}{print $1,$2}'
echo " "
echo " "
echo " "
echo " "
#join -1 2,2 -2 1,1 -o 1.1,2.1,2.2  a.txt b.txt|sort -n | awk 'BEGIN{FS=",";OFS=","}{print ","$2}' 
echo " "
echo " "
join -1 2,2 -2 1,1 -o 1.1,2.1,2.2  a.txt b.txt|sort -n | awk 'BEGIN{FS=",";OFS=","}{print ","$2}' |  awk 'BEGIN{FS=" "}{printf  "%-40s%s\n", $1,$2}'
echo " "
echo " "
echo " "
echo " "
