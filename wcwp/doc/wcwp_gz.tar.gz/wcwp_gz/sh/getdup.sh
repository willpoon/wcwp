#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
dup_field="usr_nbr"
else 
dup_field=$2
fi
select 
		${dup_field}
		, count(0) 
from
$1
group by	
		${dup_field}
having 
		count(0)>1
;
"
echo " "
echo " "
echo  "select max($dup_field) from $1 ;"
ora_exec_sql "$select_max"|sed -e '/ession/d'|sed -e '/^$/d'

