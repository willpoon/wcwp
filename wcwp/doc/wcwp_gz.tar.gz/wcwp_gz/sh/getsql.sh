deal_mon=$2
sql="
`cat $1`
"
echo $sql
