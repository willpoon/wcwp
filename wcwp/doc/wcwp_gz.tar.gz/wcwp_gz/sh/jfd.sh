#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
. $PZW_INC/common.ksh
#######################################################################################################

if [ $# -ne 2 ];then 
echo "usage: jfd <field_list_to_select> <tbs_name.txt>"
exit 1
fi
echo " "
echo " "
fields=`echo $1|sed -e 's/[A-Z]\.//g;s/ *//g;s/,/|/g'`
#echo "'"$fields"'"
#grep -iE $fields $2
grep -iE $fields $2|sort|uniq>b.txt
echo "chk b.txt"
echo " "
echo " "
#numfield "$1"
