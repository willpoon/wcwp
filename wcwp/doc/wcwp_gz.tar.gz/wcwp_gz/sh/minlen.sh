awk -f $shroot/minlen.awk -v v_del="$2" $1 
