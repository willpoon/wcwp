#echo nohup sqlplus zhengfengmei/oracle123@gzdm @`$1`/step2.run.txt.s>sqlout 2>&1 &
#nohup sqlplus -s zhengfengmei/oracle123@gzdm @`$1`/step2.run.txt.s>sqlout 2>&1 &
nohup sh -v `$1`/step2.run.txt.s>step2.run.txt.`date +%Y-%m-%d-%H:%M:%S`.log 2>&1 &
