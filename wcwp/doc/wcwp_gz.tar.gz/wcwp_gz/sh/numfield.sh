#number fields in the fields list.
if [ $# -ne 1 ];then
echo "usage: numfield <flist.txt>"
exit 1
fi
cat $1|sed -e 's/[A-Z]\.//g;s/ *//g'|awk 'BEGIN{FS=",";OFS=","}{print NR"\t",$2}'|sort  -k2,2 > a.txt
cat $1|sed -e 's/[A-Z]\.//g;s/ *//g'|awk 'BEGIN{FS=",";OFS=","}{print NR"\t",$2}'|sort  -k2,2 1
echo "chk a.txt"
