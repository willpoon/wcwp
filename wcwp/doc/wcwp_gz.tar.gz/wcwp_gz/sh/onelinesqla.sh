echo $1
#sqlplus -s chenlifeng/clf998@zhdm <<EOF
sqlplus -s dmadmin/clf999@zhdm <<EOF
set echo off;
set feedback on;
set heading on;
set pagesize 0;
--alter session force parallel query parallel 4;
--alter session force parallel dml parallel 2;
set linesize 20000;
$1
quit;
EOF
echo ""
echo ""
echo $1
echo ""
echo ""
