echo $1
#sqlplus -s chenlifeng/clf000@zhdm <<EOF
sqlplus -s dmadmin/clf999@zhdm <<EOF
set echo off;
set feedback on;
set heading on;
set pagesize 0;
ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION FORCE PARALLEL query PARALLEL 30;
ALTER SESSION FORCE PARALLEL DML PARALLEL 30;
set linesize 20000;
$1
quit;
EOF
echo ""
echo ""
echo $1
echo ""
echo ""
