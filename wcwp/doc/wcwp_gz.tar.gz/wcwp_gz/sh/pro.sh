#/bin/ksh
alias cdo='cd /gmcc_data/gz/zhengfm/wugh/outdata' 
alias cdi='cd /gmcc_data/gz/zhengfm/wugh/indata'
alias tel211='telnet 10.243.216.211'

ftab()
{
tabname1=`echo $1 | tr [a-z] [A-Z]`
tabname2=`echo $2 | tr [a-z] [A-Z]`
tabname3=`echo $3 | tr [a-z] [A-Z]`
echo "select owner||'.'||table_name||' -  '||NUM_ROWS from all_tables where table_name like '%${tabname1}%${tabname2}%${tabname3}%' order by table_name ;">.sql.tmp
echo "quit" >>.sql.tmp
sqlplus  chenlifeng/clf998@zhdm @.sql.tmp
}

##ftab1()
##{
##tabname1=`echo $1 | tr [a-z] [A-Z]`
##tabname2=`echo $2 | tr [a-z] [A-Z]`
##tabname3=`echo $3 | tr [a-z] [A-Z]`
##! echo "select owner||'.'||view_name from all_views  where view_name like '%${tabname1}%${tabname2}%${tabname3}%' order by view_name ;">.sql.tmp
##sqlplus  zhengfengmei/tds200904@gzdm @.sql.tmp 
##}

##ftab2()
##{
##tabname1=`echo $1 | tr [a-z] [A-Z]`
##tabname2=`echo $2 | tr [a-z] [A-Z]`
##tabname3=`echo $3 | tr [a-z] [A-Z]`
##tabname4=`echo $4 | tr [a-z] [A-Z]`
##! echo "select owner||'.'||view_name from all_views  where view_name like '%${tabname1}%${tabname2}%${tabname3}%' and  view_name not like '%${tabname4}%'  order by view_name;">.sql.tmp
##sqlplus  zhengfengmei/tds200904@gzdm @.sql.tmp
##}

des()
{
tabname=`echo $1 | tr [a-z] [A-Z]`
tabcol=`echo $2 | tr [a-z] [A-Z]`
! echo "desc ${tabname} ;">.sql.tmp
sqlplus  zhengfengmei/tds200904@gzdm @.sql.tmp
}

fidx()
{
idxname=`echo $1 | tr [a-z] [A-Z]`
! echo "select TABLE_NAME,index_name from  all_indexes where INDEX_NAME like '%${idxname}%' ;">.sql.tmp
sqlplus  zhengfengmei/tds200904@gzdm @.sql.tmp
}

#alias con2='sqlplus zhengfengmei/tds200904@gzdm'

alias con3='sh ./.condm.sh'

sh /gmcc_data/gz/zhengfm/wugh/.log.sh

ora_exec_sql(){
sqlplus -s zhengfengmei/tds200904@gzdm<<EOF
set echo off
alter session force parallel query parallel 30;
alter session force parallel dml parallel 30;
set autocommit on
set pagesize 0
set heading on
set echo on
$1
quit
EOF
}
