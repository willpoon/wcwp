#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
sel_field="*"
else 
sel_field="$2"
fi
sel_10="
set linesize 20000;
set colsep |
select $sel_field
from $1 where rownum<=10;
"
echo " "
echo " "
echo  "select $sel_field  from $1 ;"
ora_exec_sql "$sel_10"

