echo "sed -e 's/^M//g' $1 >$1.s"
sed -e 's///g' $1 >$1.s
