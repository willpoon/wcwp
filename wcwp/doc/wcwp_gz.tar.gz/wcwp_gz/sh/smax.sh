#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
max_field="usr_nbr"
else 
max_field=$2
fi
select_max="
select max($max_field) 
from $1
;
"
echo " "
echo " "
echo  "select max($max_field) from $1 ;"
ora_exec_sql "$select_max"|sed -e '/ession/d'|sed -e '/^$/d'

