#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
min_field="usr_nbr"
else 
min_field=$2
fi
select_min="
select min($min_field) 
from $1
;
"
echo " "
echo " "
echo  "select min($min_field) from $1 ;"
ora_exec_sql "$select_min"|sed -e '/ession/d'|sed -e '/^$/d'

