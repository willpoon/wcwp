if [ $# -lt 2 ]
then
echo "usage: spool <output_condiction> <out_filenam> <output_format_if_necessory>"
exit 1
fi
##processing 2 paras.
if [ $# -eq 2 ] ;then 
echo set colsep ',' >.tmp.sql
echo set pagesize 0 >>.tmp.sql
echo set heading off >>.tmp.sql
echo set echo off >>.tmp.sql
echo set feedback off >>.tmp.sql
echo set termout off >>.tmp.sql
echo set trimspool on >>.tmp.sql
echo set linesize 3000 >>.tmp.sql
echo "spool ./rs_$2">>.tmp.sql
cat .tmp.sql $1>.tmp2.sql
echo "spool off">>.tmp2.sql
echo quit >>.tmp2.sql
cat .tmp.sql
rm .tmp.sql
if [ `echo $2|awk -v v_para_2=$2  '{print index(v_para_2,"csv")}'` -gt 0 ];then
#output sep by ","
sed -e "s/^,/\|\|\',\'\|\|/g" .tmp2.sql > .tmp3.sql
else
#output sep by "|"
sed -e "s/^,/\|\|\'\|\'\|\|/g" .tmp2.sql > .tmp3.sql
fi
cat .tmp2.sql
rm .tmp2.sql
sqlplus -s chenlifeng/clf000@zhdm @.tmp3.sql
rm .tmp3.sql
else
#processing 3 paras;
echo set colsep ',' >.tmp.sql
echo set pagesize 0 >>.tmp.sql
echo set heading off >>.tmp.sql
echo set echo off >>.tmp.sql
echo set feedback off >>.tmp.sql
echo set termout off >>.tmp.sql
echo set trimspool on >>.tmp.sql
echo set linesize 3000 >>.tmp.sql
#add column formating here
echo "$3">>.tmp.sql
echo "spool ./rs_$2">>.tmp.sql
cat .tmp.sql $1>.tmp2.sql
echo "spool off">>.tmp2.sql
echo quit >>.tmp2.sql
cat .tmp.sql
rm .tmp.sql
if [ `echo $2|awk -v v_para_2=$2  '{print index(v_para_2,"csv")}'` -gt 0 ];then 
#output sep by ","
sed -e "s/^,/\|\|\',\'\|\|/g" .tmp2.sql > .tmp3.sql
else 
#output sep by "|"
sed -e "s/^,/\|\|\'\|\'\|\|/g" .tmp2.sql > .tmp3.sql
fi
cat .tmp2.sql
rm .tmp2.sql
sqlplus -s chenlifeng/clf000@zhdm @.tmp3.sql
rm .tmp3.sql
fi
