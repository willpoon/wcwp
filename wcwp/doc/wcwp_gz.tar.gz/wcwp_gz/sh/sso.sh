. $PZW_INC/common.ksh
sch1=A

echo " "
echo " "
echo  spool_out\=\"
echo "SELECT"
for fields in `descf $1|sed -e 's/,//g`
do 
echo ","${sch1}.${fields}
done
echo FROM
echo      "		"$1 ${sch1}|tr [a-z] [A-Z]
echo \;
echo \"
echo " "
echo "echo "\"\$spool_out\"\>spool_out.sql
echo "spool" spool_out.sql outfile_nam.txt
echo " "
echo " "
