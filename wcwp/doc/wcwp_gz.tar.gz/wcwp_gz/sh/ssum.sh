#######################################################################################################
#!/usr/bin/ksh
#author : panzw 
#purse : perform a quick dupliacte_checksum
. $PZW_INC/common.ksh
#######################################################################################################
if [  $# -eq 1 ] 
then 
sum_field="usr_nbr"
else 
sum_field=$2
fi
select_sum="
select sum($sum_field) 
from $1
;
"
echo " "
echo " "
echo  "select sum($sum_field) from $1 ;"
ora_exec_sql "$select_sum"|sed -e '/ession/d'|sed -e '/^$/d'

