for v_file in `ls -1 *$1*`
do 
echo $v_file
tail $v_file
done
