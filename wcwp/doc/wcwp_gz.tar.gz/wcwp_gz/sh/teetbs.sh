. $PZW_INC/common.ksh
if [ $# -ne 1 ];then 
echo "usage: teetbs <tb> <tbs_name.txt>"
exit 1
fi
desc $1 | tee -a tbs_name.txt
