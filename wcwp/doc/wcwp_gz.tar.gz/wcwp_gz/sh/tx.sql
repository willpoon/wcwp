select 
 A_USR_NBR             
,BRND_CD              
,INNET_MO_CNT         
,CURRMO_AMT_FEE      
,CURRMO_VOCCALL_FEE   
,TT_GPRS_FEE                     
,GPRS_TAOCAN_CD         
,GPRS_TAOCAN_NAM        
from   ZHENGFENGMEI.KT_PZW_AB090306018_RS_200902
where BRND_CD = 1
and     IN_LIST= 1
and rownum <10
;

