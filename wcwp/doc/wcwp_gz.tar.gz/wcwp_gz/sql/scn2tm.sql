SQL> select usr_nbr,scn_to_timestamp(ora_rowscn) from ods.to_iusr where usr_nbr = '13676219663';
13676219663
20-MAR-09 05.58.21.000000000 AM
