. $PZW_INC/common.ksh
connect_db
sql="select
*
from ref.tr_dir_typ
order by 1;
"
exec_sql "$sql" 
connect_close
exit


