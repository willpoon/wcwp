sqlplus zhengfengmei/oracle123@gzdm<<EOF
set heading off;
select table_name from all_tables where table_name like '%TO_OCS_CHRG_LOG%' and rownum<1000 order by table_name ;
describe ODS.TO_OCS_CHRG_LOG_200810;
alter session force parallel query parallel 8;
alter session force parallel dml parallel 8;
set linesize 32767;
select * from  ODS.TO_OCS_CHRG_LOG_200810 where TM_INTRVL_CD=20081026 and rownum<10;
elect substr(TRADE_DTIM,1,8),count(*) from ODS.TO_OCS_CHRG_LOG_200810 group by substr(TRADE_DTIM,1,8) order by 1;
elect * from   ODS.TO_OCS_CHRG_LOG_200810 where rownum<10;
elect TM_INTRVL_CD ,count(*) from  ODS.TO_OCS_CHRG_LOG_200810 group by TM_INTRVL_CD  order by 1 ; 
elect TM_INTRVL_CD,count(*) from   ODS.TO_IUSR_CHRG_LOG_200808 group by  TM_INTRVL_CD order by 1;
quit;
EOF

