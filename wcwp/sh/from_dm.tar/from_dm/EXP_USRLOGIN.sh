#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#	EXP_USRLOGIN.sh  <datadate> <dataarea> <outfile> 
# 
# 
# PARAMETERs:
#     datadate      
#     dataarea        
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070607   NieJian           �½�

######################################################################

# д��־��shell����

writelog()
{
  echo `date "+%Y-%m-%d %H:%M:%S"`" $1" | tee -a $logfile
}

if [ $# -ne 3 ]
then
        echo "Usage:$0  <dataarea> <full_file_name>  <sql_str>"
        writelog "Usage:`basename $0` user/pass@database export_file sql"
exit 1
fi

datadate=$1
dataarea=$2
outfile=$3

#section���ӱ�������ini�ļ�

if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi

logfile=$BIPROG_ROOT/log/`basename $0`.log


iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}password`

usrid=${dbuser}/${dbpasswd}@${dbname}

writelog "export file $outfile begin"

tmpdir=$BIPROG_ROOT/tmp
fname2=$tmpdir/$$`basename $outfile`2
fname3=$tmpdir/$$`basename $outfile`3

writelog "export  start"
sqlplus $usrid <<EOF >/dev/null
 set echo off;
 set heading off ;
 set feedback off;
 set pagesize 0 ;
 set linesize 2000;
 set termout off;
 set trimout on;
 set trimspool on;
 spool $fname2;
 select 'DW&&'||to_char(user_id)||'&&'||to_char(login_time,'YYYY-MM-DD HH:MM:SS')||'&&'||'1'||'&&'||'${dataarea}'||'&&'  
 from frnt.tn_USER_LOGIN_INFO
 where to_char(login_time,'YYYYMMDD')=${datadate} 
 union all
 select 'DW&&'||to_char(user_name)||'&&'||to_char(login_dt,'YYYY-MM-DD HH:MM:SS')||'&&'||'-1'||'&&'||'${dataarea}'||'&&'  
 from frnt.tn_login_log
 where to_char(login_Dt,'YYYYMMDD')=${datadate} ;
 spool off ;
exit
EOF

if [ "$?" -ne 0 ] ;
then
 echo "Error:sqlplus $usrid error in unload table !! "
 echo "Please check userid and passwd or database."
 exit
fi

writelog "export  success, wait���������������� "

#sed  -e '/^SQL>/d' -e '/^$/d' $fname2 >$fname3
grep '^DW' $fname2 > $fname3
rm $fname2
cnt2=`wc -l $fname3 |awk '{print($1)}'`
echo "HDR2${cnt2}"  >>$fname3
compress -f $fname3

mv ${fname3}.Z ${outfile}.Z

writelog "export $cnt2 rows "
writelog "export $outfile end "
