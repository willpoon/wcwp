#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#	EXP_USRVST.sh  <datadate> <dataarea> <outfile> 
# 
# 
# PARAMETERs:
#     datadate      
#     dataarea        
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070607   NieJian           �½�

######################################################################

# д��־��shell����

writelog()
{
  echo `date "+%Y-%m-%d %H:%M:%S"`" $1" | tee -a $logfile
}

if [ $# -ne 3 ]
then
        echo "Usage:$0  <dataarea> <full_file_name>  <sql_str>"
        writelog "Usage:`basename $0` user/pass@database export_file sql"
exit 1
fi

datadate=$1
dataarea=$2
outfile=$3

#section���ӱ�������ini�ļ�

if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi

logfile=$BIPROG_ROOT/log/`basename $0`.log


iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}password`

usrid=${dbuser}/${dbpasswd}@${dbname}

writelog "export file $outfile begin"

tmpdir=$BIPROG_ROOT/tmp
fname2=$tmpdir/$$`basename $outfile`2
fname3=$tmpdir/$$`basename $outfile`3

writelog "export  start"
sqlplus $usrid <<EOF >/dev/null
 set echo off;
 set heading off ;
 set feedback off;
 set pagesize 0 ;
 set linesize 2000;
 set termout off;
 set trimout on;
 set trimspool on;
 spool $fname2;
 select 'DW&&'||to_char(user_id)||'&&'||to_char(CALL_TIME,'YYYY-MM-DD HH:MM:SS')||'&&'||a.menu_id||'&&'||b.menu_name||'&&'||'${dataarea}'||'&&' 
 from frnt.TN_USER_SLOT a,frnt.tn_menu b
 where a.menu_id=b.menu_id
       and to_char(call_time,'YYYYMMDD')=${datadate};
 spool off ;
exit
EOF

if [ "$?" -ne 0 ] ;
then
 echo "Error:sqlplus $usrid error in unload table !! "
 echo "Please check userid and passwd or database."
 exit
fi

writelog "export  success, wait���������������� "

#sed  -e '/^SQL>/d' -e '/^$/d' $fname2 >$fname3
grep '^DW' $fname2 > $fname3
#rm $fname2
cnt2=`wc -l $fname3 |awk '{print($1)}'`
echo "HDR2${cnt2}"  >>$fname3
compress -f $fname3

mv ${fname3}.Z ${outfile}.Z
writelog "export $cnt2 rows "
writelog "export $outfile end "
