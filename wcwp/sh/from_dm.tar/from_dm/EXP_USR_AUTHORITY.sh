#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#	EXP_USR_AUTHORITY.sh  <datadate> <dataarea> <outfile> 
# 
# 
# PARAMETERs:
#     datadate      
#     dataarea        
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070620   NieJian           �½�
# 20070815   NieJian   �޸���������ļ��е�����sql����
######################################################################

# д��־��shell����

writelog()
{
  echo `date "+%Y-%m-%d %H:%M:%S"`" $1" | tee -a $logfile
}

if [ $# -ne 3 ]
then
        echo "Usage:$0  <datadate> <dataarea> <outfile> "
        writelog "Usage:`basename $0` user/pass@database export_file sql"
exit 1
fi

datadate=$1
dataarea=$2
outfile=$3

#section���ӱ�������ini�ļ�

if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi

logfile=$BIPROG_ROOT/log/`basename $0`.log


iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}password`

usrid=${dbuser}/${dbpasswd}@${dbname}

writelog "export file $outfile begin"

tmpdir=$BIPROG_ROOT/tmp
fname2=$tmpdir/$$`basename $outfile`2
fname3=$tmpdir/$$`basename $outfile`3

writelog "export  start"
sqlplus $usrid <<EOF >/dev/null
 set echo off;
 set heading off ;
 set feedback off;
 set pagesize 0 ;
 set linesize 2000;
 set termout off;
 set trimout on;
 set trimspool on;
 spool $fname2;
 select '&&'||'${dataarea}'||'&&'||a.user_id||'&&'||b.menu_id||'&&'||c.parent_id||'&&'||c.menu_name||'&&'||c.menu_type||'&&'
from  frnt.tn_user a ,frnt.tn_menu_of_role b,frnt.tn_menu c
where a.role_id=b.role_id and b.menu_id=c.menu_id ;
 spool off ;
exit
EOF

if [ "$?" -ne 0 ] ;
then
 echo "Error:sqlplus $usrid error in unload table !! "
 echo "Please check userid and passwd or database."
 exit
fi

writelog "export  success, wait���������������� "

##��������ļ��е�����sql
sed -e '/^&&/!d' -e 's/^&&//' $fname2 >$fname3

rm $fname2
cnt2=`wc -l $fname3 |awk '{print($1)}'`
#echo "HDR2${cnt2}"  >>$fname3
compress -f $fname3

mv ${fname3}.Z ${outfile}.Z

writelog "export $cnt2 rows "
writelog "export $outfile end "


