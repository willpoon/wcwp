#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#	EXP_USR_INF.sh  <datadate> <dataarea> <outfile> 
# 
# 
# PARAMETERs:
#     datadate      
#     dataarea        
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070620   NieJian           �½�
# 20070813   NieJian        ���Ӽ��ܽ���
######################################################################

# д��־��shell����

writelog()
{
  echo `date "+%Y-%m-%d %H:%M:%S"`" $1" | tee -a $logfile
}

if [ $# -ne 3 ]
then
        echo "Usage:$0   <datadate> <dataarea> <outfile> "
        writelog "Usage:`basename $0` user/pass@database export_file sql"
exit 1
fi

datadate=$1
dataarea=$2
outfile=$3

datamon=`echo "substr(${datadate},0,6)"|m4`
echo "${datadate},,,,${datamon}"

#section���ӱ�������ini�ļ�

if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi

logfile=$BIPROG_ROOT/log/`basename $0`.log


iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}password`

usrid=${dbuser}/${dbpasswd}@${dbname}

writelog "export file $outfile begin"

tmpdir=$BIPROG_ROOT/tmp
fname2=$tmpdir/$$`basename $outfile`2
fname3=$tmpdir/$$`basename $outfile`3

writelog "export  start"
sqlplus $usrid <<EOF >/dev/null
 set echo off;
 set heading off ;
 set feedback off;
 set pagesize 0 ;
 set linesize 2000;
 set termout off;
 set trimout on;
 set trimspool on;
 spool $fname2;
select '&&'||m.user_id||'&&'||m.user_name||'&&'||m.pwd||'&&'||m.e_mail||'&&'||m.phone_number||'&&'||'${dataarea}'||'&&'||m.distict||'&&'||m.town||'&&'||m.busioffice||'&&'||'1'||'&&'
from
(select  a.user_id,a.user_name,a.pwd,a.e_mail,a.phone_number,
case length(a.CTY_AREA_ID)   when 2 then '' when 4 then a.cty_area_id 
     when 6 then (select distinct cmcc_branch_cd from ref.tr_mrkt_chnl_area_sz b where a.cty_area_id=b.sub_branch_cd and tm_intrvl_cd=${datamon} )
     when 10 then  (select distinct cmcc_branch_cd from ref.tr_mrkt_chnl_area_sz b where a.cty_area_id=b.mrkt_chnl_id and tm_intrvl_cd=${datamon} )
     else '' end  distict,
case length(a.CTY_AREA_ID)   when 2 then '' when 4 then '' 
     when 6 then a.cty_area_id
     when 10 then  (select distinct sub_branch_cd from ref.tr_mrkt_chnl_area_sz b where a.cty_area_id=b.mrkt_chnl_id and tm_intrvl_cd=${datamon} )
     else '' end  town,      
case length(a.CTY_AREA_ID)   
     when 10 then a.cty_area_id
     else '' end  busioffice        
from frnt.tn_user   a
) m ;
spool off ;
exit
EOF

if [ "$?" -ne 0 ] ;
then
 echo "Error:sqlplus $usrid error in unload table !! "
 echo "Please check userid and passwd or database."
 exit $?
fi

writelog "export  success, wait���������������� "

##��������ļ��е�����sql
sed -e '/^&&/!d' -e 's/^&&//' $fname2 >$fname3


##�����ݿ�frnt.tn_user ���е������Ѽ��ܵ��û��������
writelog "BiPwdFile Start"

java -cp pwdfile.jar:mail-impl.jar com.congxing.bi.modules.pwdfilemanager.PwdFile -mathod BiPwdFile -file ${fname3} -col 3 -del "&&"

if [ "$?" -ne 0 ] ;
then
 echo "Error:BiPwdFile error !!  $?"
 exit $?
fi
writelog "BiPwdFile End"


##���ṩ��desskey ��pwd�м���,���������ļ�
writelog "EncryptPwdFile Start"

java -cp pwdfile.jar:mail-impl.jar: com.congxing.bi.modules.pwdfilemanager.PwdFile -mathod EncryptPwdFile -file ${fname3} -col 3 -del "&&" -key bikey.dat

if [ "$?" -ne 0 ] ;
then
 echo "Error:EncryptPwdFile error !!  $?"
 exit $?
fi
writelog "EncryptPwdFile End"


rm $fname2
cnt2=`wc -l $fname3 |awk '{print($1)}'`
#echo "HDR2${cnt2}"  >>$fname3
compress -f $fname3

mv ${fname3}.Z ${outfile}.Z

writelog "export $cnt2 rows "
writelog "export $outfile end "

