#!/bin/ksh
#************************************************************************
#Function:\t compress and backup too many file for dss
#Useage:\t usage:$0 'filelist expression'
#Useage:\t usage:$0 '/tmp/*'
#Author:\t Deng Chongwei
#*Version:\t 0.9.0
#modified history :
#v01.00.000     dengchongwei    ���
#!/bin/ksh
#************************************************************************
#Function:\t compress and backup too many file for dss
#Useage:\t usage:$0 'filelist expression'
#Useage:\t usage:$0 '/tmp/*'
#Author:\t Deng Chongwei
#*Version:\t 0.9.0
#modified history :
#v01.00.000     dengchongwei    ���
#************************************************************************

errlog()
{
  format=`date +%Y-%m-%d"  "%H:%M:%S`"  Shell P_ID[$$]:"
  echo "$format $1"|tee -a ./`basename $0`.log 2>&1
}

if [ $# -ne 1 ]
then
  errlog "usage:$0 'filelist expression'"
  errlog "para error,please recall!"
  exit 1
fi


#�ж�BIPROG_ROOT�����Ƿ�����
if [ -z "$BIPROG_ROOT" ]
then
  errlog "Please set environment variable:BIPROG_ROOT"
  errlog "Or The directory:$BIPROG_ROOT/log don't exists."
fi

logfile=$BIPROG_ROOT/log/`basename $0`.log

log()
{
  format=`date +%Y-%m-%d"  "%H:%M:%S`"  Shell P_ID[$$]:"
  echo "$format $1">>$logfile 2>&1
}

log "BEGIN compress and backup $1"

for file in $1
do
  compress -f $file>>$logfile 2>&1
  if [ $? -ne 0 ]
  then
    log "Warnning: compress ${file} failed."
    exit 1
  fi

  filename=`basename $file`
  pdirname=`dirname $file`
  ppdirname=`dirname ${pdirname}`
  bakpath=${ppdirname}/BAK
  comfile=${file}.Z
  bakfile=${bakpath}/${filename}.Z
  mv $comfile $bakfile>>$logfile 2>&1
  if [ $? -ne 0 ]
  then
    log "Warnning: backup ${file} failed."
    exit 1
  fi
done

log "FINISH compress and backup $1"

