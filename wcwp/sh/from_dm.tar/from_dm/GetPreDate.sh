#!/bin/sh
# Author : Xiao zhangwu
# Version: 00.00.001

progname=`basename $0`
logfile=$BIPROG_ROOT/log/${progname%.sh}.log
if [ $# -ne 1 ]
then
	echo "Usage: $progname <yyyymmdd>" >> ${logfile}
	exit -1;
fi

date=$1
year=`echo $date | cut -b'1-4'`
month=`echo $date | cut -b'5-6'`
day=`echo $date | cut -b'7-8'`

day=`expr $day - 1`
if [ $day -eq 0 ]
then
	month=`expr $month - 1`
	if [ $month -eq 0 ]
	then
		day=31
		month=12
		year=`expr $year - 1`
	fi
	
	if [ $month -eq 1 ] || [ $month -eq 3 ] || [ $month -eq 5 ] || [ $month -eq 7 ] || [ $month -eq 8 ] || [ $month -eq 10 ]
	then
		day=31
	fi

	if [ $month -eq 2 ]
	then
		y4=`expr $year % 4`
		y100=`expr $year % 100`
		y400=`expr $year % 400`
		day=28
		if [ $y4 -eq 0 ] && [ $y100 -ne 0 ]
		then
			day=29
		fi
		if [ $y400 -eq 0 ]
		then
			day=29
		fi
	fi

	if [ $month -eq 4 ] || [ $month -eq 6 ] || [ $month -eq 9 ] || [ $month -eq 11 ]
	then
		day=30
	fi

	if [ $month -le 9 ]
	then
		month=0$month
	fi

fi

if [ $day -le 9 ]
then
	day=0$day
fi

date=$year$month$day

echo $date

exit 0

