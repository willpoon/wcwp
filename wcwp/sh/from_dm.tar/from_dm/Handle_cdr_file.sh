#!/usr/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.001
# ������:(2008)BIDM-0519
# USAGE:
#	Handle_cdr_file.sh  <date> 
# 
# PARAMETERs:
#     YYYYMMDD     date string,such as 20081108 etc.
#     
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20081118  zhengyalin           �½�
###############################################################################

if [ $# -ne 1 ]
then
	echo " Parameter ERROR!"
	echo " Usage:`basename $0` YYYYMMDD "
	exit 1
fi 

log_file=$BIPROG_ROOT/log/`basename $0`.log

writelog()
{
  echo `date '+%Y-%m-%d %H:%M:%S'`" $1"  >> $log_file
}

# ��ȡftp�ʺ� ����
#iniFileName=$BIPROG_ROOT/config/prog.ini
#username=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName acrm_ftp username`
#password=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName acrm_ftp password`


# ����ftp�ű� �� prog.ini ��ͷΪ [acrm_ftp]
echo "#!/usr/bin/sh
# \$1 -- temperater fileName such as CDR20081010000001.pre.Z.tmp
# \$2 -- fileName  ,such as CDR20081010000001.pre.Z  
#user $username $password
ftp -i -n 10.243.216.211 <<EOF
user gzyd gzyd
cd  /data/JAD_CDR/_EXF/  
lcd /etl1_data/JAD_CDR/GZ/ACRM_PRE/
prom
bin
put \$1
rename \$1  \$2
by
EOF
" > /etl1_data/JAD_CDR/GZ/ACRM_PRE/put_cdr_file.sh

chmod 777 /etl1_data/JAD_CDR/GZ/ACRM_PRE/put_cdr_file.sh

writelog " ---Start Handle ---- "
time_string=$1

cd /etl1_data/JAD_CDR/GZ/ACRM_PRE/

file_count=`ls /etl1_data/JAD_CDR/GZ/PRE/CDR${time_string}* | wc -l | awk '{print $1;}'`
if [ $file_count -ne 0  ]
then
for file_name in /etl1_data/JAD_CDR/GZ/PRE/CDR${time_string}*
do
new_fileName=`basename $file_name`

writelog $new_fileName

cat $file_name | awk 'BEGIN{FS=OFS="&"}{$25=0;print $0;}' > /etl1_data/JAD_CDR/GZ/ACRM_PRE/$new_fileName

compress -f /etl1_data/JAD_CDR/GZ/ACRM_PRE/$new_fileName

mv /etl1_data/JAD_CDR/GZ/ACRM_PRE/${new_fileName}.Z  /etl1_data/JAD_CDR/GZ/ACRM_PRE/${new_fileName}.Z.tmp 

/etl1_data/JAD_CDR/GZ/ACRM_PRE/put_cdr_file.sh  ${new_fileName}.Z.tmp   ${new_fileName}.Z

# ɾ���Ѿ�������211��ѹ���ļ���

rm  /etl1_data/JAD_CDR/GZ/ACRM_PRE/${new_fileName}.Z.tmp > /dev/null
done
fi 

# ����list�ļ�

cat /etl1_data/JAD_CDR/_BACK/CDR${time_string}.GZ.list | awk '{if(length($2)>15){print $0".Z"} else {print $0;}}' >  /etl1_data/JAD_CDR/GZ/ACRM_PRE/CDR${time_string}.GZ.list.tmp

writelog  CDR${time_string}.GZ.list

/etl1_data/JAD_CDR/GZ/ACRM_PRE/put_cdr_file.sh  CDR${time_string}.GZ.list.tmp CDR${time_string}.GZ.list

rm /etl1_data/JAD_CDR/GZ/ACRM_PRE/CDR${time_string}.GZ.list.tmp > /dev/null

writelog " ---END Handle ---- "
writelog "  "
