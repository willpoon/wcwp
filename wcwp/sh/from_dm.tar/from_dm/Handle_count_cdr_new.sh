#!/usr/bin/sh


if [ $# -ne 2 ]
then 
        echo "parameter ERROR"
        echo "Usage:`basename $0` YYYYMMDD CITY "
        exit 1
fi

date_string=$1
city=$2
datapath=/etl1_data

log_file=$BIPROG_ROOT/log/`basename $0`.log
writelog()
{
  echo `date '+%Y-%m-%d %H:%M:%S'`" $1"  >> $log_file
}

iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 password`
writelog " $date_string $city "
writelog " Connect to database ( $dbname ) ..."

db2 "connect to $dbname user $dbuser using $dbpasswd " > /dev/null

retcode=$?
if [ $retcode -ne 0 ]
then       
        writelog " Connect to $dbname Failed . "
        exit 1
fi

db2 "delete from ctl.ta_etl_err_log where date='$date_string' and DISTRICT='$city' and ds_id=1001 and PROCESS_STEP=1 with ur" > /dev/null
retcode=$?
if [ $retcode -ne 0 -a $retcode -ne 1 -a $retcode -ne 2 ]
then       
        writelog " SQL EXECUTE ERROR "
        exit 1
fi

writelog " --- Start count ------ "

for file in ${datapath}/JAD_CDR/${city}/PRE/CDR${date_string}*.pre
do
fileName=`basename $file`

file_count=`wc -l $file | awk '{print $1;}'`
retcode=$?
if [ $retcode -ne 0 ]
then       
        writelog " WC -L execute error . "
        exit 1
fi             
writelog " $fileName record is : $file_count "

db2 "insert into ctl.ta_etl_err_log values ('$date_string','$city',1001,1,33056,'$file','$fileName',-1,$file_count,$file_count,0,0,0,0,1,$file_count) with ur"

retcode=$?
if [ $retcode -ne 0 ]
then       
        writelog " SQL EXECUTE ERROR "
        exit 1
fi

done

writelog  " ---- END ---- " 

writelog  " " 


