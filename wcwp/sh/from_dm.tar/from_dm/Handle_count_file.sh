#!/usr/bin/sh
#####################################################################################
# FILENAME: Handle_count_file.sh
# VERSION : 01.00.001
# 
# USAGE:
#       Handle_count_file.sh <AIM_DIR>  <AIM_FILENAME> <DS_ID>  <CITY>  <YYYYMMDD>  
# 
# PARAMETERs:
#     <AIM_DIR>       aim file directory , such as /etl1_data/JAD_CDR/GZ/PRE
#     <AIM_FILENAME>  aim file name , such as CDR20090101.GZ.00001.pre 
#     <DS_ID>         dataSource ID , such as 1001
#     <CITY>          city name , such as GZ etc.
#     <YYYYMMDD>      dataString , such as 20090101
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20090101  zhengyalin           �½� �� ����������(2009)BIDM-0007
#####################################################################################

if [ $# -ne 5 ]
then
        echo " Parameter ERROR "
        echo " Please input right Parameters, THANK YOU "
        echo "Usage:`basename $0` AIM_DIR AIM_FILENAME DS_ID CITY  YYYYMMDD"
        exit 1
fi 

aim_dir=$1
file_name=$2
ds_id=$3
city=$4
data_string=$5

log_file=$BIPROG_ROOT/log/`basename $0`_${city}.log

writelog()
{
  echo `date '+%Y-%m-%d %H:%M:%S'`" $1"  >> $log_file
}


# ��ȡftp�ʺ� ���� DATAMART
iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 password`

writelog " Connecting to database ($dbname)... "
db2 connect to $dbname user $dbuser using $dbpasswd

retcode=$?
   
if [ $retcode -ne 0 ]
then  
  writelog " First connect to $dbname Failed."
  writelog " ReConnect to $dbname "
  sleep 5
  db2 connect to DATAMART  user etl  using  Mmxgl
  retcode=$?
  
  if [ $retcode -ne 0 ]
  then  
          writelog "Second connect to $dbname Failed."
          writelog " ERROR EXIT "
          exit 1
  fi
 
fi


file_count=`wc -l ${aim_dir}/${file_name} | awk '{print $1;}'`

retcode=$?
   
if [ $retcode -ne 0 ]
then  
        writelog " First WC -L Failed "
        writelog " REDO WC -L "
        file_count=`wc -l ${aim_dir}/${file_name} | awk '{print $1;}'`
  retcode=$?   
  if [ $retcode -ne 0 ]
     then
         writelog " Second WC -L Failed "
         writelog " ERROR EXIT "
         exit 1
   fi
fi

writelog  "  ${aim_dir}/${file_name} retcode is : $file_count "

pid=$$

db2 "insert into ctl.ta_etl_err_log (DATE,DISTRICT,DS_ID,PROCESS_STEP,PID,OUT_FILENAME,FILE_NAME,DS_FIELD_ID,SOUR_RECORD,SUCCE_RECORD,FAIL_RECORD,REPEAT_DEL_RECORD,LOAD_REJ_RECORD,LOAD_SKIP_RECORD,RESULT_FLAG,OUTFILE_LINENUM ) \
  values ('${data_string}','${city}',${ds_id},1,${pid},'${aim_dir}/${file_name}','${file_name}',-1,${file_count},${file_count},0,0,0,0,1,${file_count})"

retcode=$?
   
if [ $retcode -ne 0 ]
then  
        writelog " First insert into database  Failed "
        writelog " REDO insert again "
        
        db2 "insert into ctl.ta_etl_err_log (DATE,DISTRICT,DS_ID,PROCESS_STEP,PID,OUT_FILENAME,FILE_NAME,DS_FIELD_ID,SOUR_RECORD,SUCCE_RECORD,FAIL_RECORD,REPEAT_DEL_RECORD,LOAD_REJ_RECORD,LOAD_SKIP_RECORD,RESULT_FLAG,OUTFILE_LINENUM ) \
  values ('${data_string}','${city}',${ds_id},1,${pid},'${aim_dir}/${file_name}','${file_name}',-1,${file_count},${file_count},0,0,0,0,1,${file_count})"
 
  if [ $retcode -ne 0 ]
  then  
        writelog " Second insert into database  Failed "
        writelog "database ERROR exit "
        exit 1
   fi
  writelog " ReInsert OK "
fi 

writelog " "

