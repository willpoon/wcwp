#!/usr/bin/sh
#####################################################################################
# FILENAME: Handle_send_cmp_file_etl1.sh
# VERSION : 01.00.001
# USAGE:
#       Handle_send_cmp_file_etl1.sh  <CITY>   
# 
# PARAMETERS:
#     CITY     city name ,such as ZH etc.
#     
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20081108  zhengyalin           create
#####################################################################################
BIPROG_ROOT=/ETL1_CX/etl/dssprog

if [ $# -ne 1 ]
then
        echo " Parameter ERROR "
        echo " Usage:`basename $0`  <CITY>  "
        exit 1
fi 

city=$1
#date_seg=$2
log_file=$BIPROG_ROOT/log/`basename $0`.log

writelog()
{
  echo `date '+%Y-%m-%d %H:%M:%S'`" $1"  >> $log_file
}

# ��ȡ��һ���ʱ���ַ���
get_predate_string()
{
file_date=$1

year=`echo ${file_date} | cut -c 1-4` 
month=`echo ${file_date} | cut -c 5-6` 
day=`echo ${file_date} | cut -c 7-8` 

if [ ${day} -eq 1 ]
then 
   if [  ${month}  -eq 1 ] 
   then 
       year=`expr ${year} - 1` 
       month=12 
   else 
       month=`expr ${month} - 1` 
   fi 
     
   day=`cal ${month} ${year} | awk '{if( NF != 0)print $0;}'|tail -n1 |awk '{print $NF}'` 

else 
        day=`expr ${day} - 1` 
fi 

pre_date=`echo "${year} ${month} ${day}"|awk '{if(length($2)==1)$2=0$2;if(length($3)==1)$3=0$3;print $1""$2""$3}'`

return 0
}

pre_date=20080101

# ʵ��ln���� ע��Ŀ¼����Ҫ��б�� /  such as : /etl/app/ etc.
ln_func()
{
dataDir=$1
fileName=$2
preFileName=$3

ls ${dataDir}${fileName} > /dev/null

if [ $? -eq 0 ]
then
	cp   ${dataDir}${fileName} /ETL1_QAD/_SEND/
        ln /ETL1_QAD/_SEND/${fileName}  /ETL1_QAD/_SEND/FS/
        rm  /ETL1_QAD/_SEND/${fileName} > /dev/null
        ls ${dataDir}${fileName} >> $log_file
else
        grep "${preFileName}" $log_file > /dev/null
        if [ $? -ne 0 ]
        then
          ls ${dataDir}${preFileName} > /dev/null
                  if [ $? -eq 0 ] 
                  then
                      cp   ${dataDir}${preFileName} /ETL1_QAD/_SEND/
                      ln /ETL1_QAD/_SEND/${preFileName}  /ETL1_QAD/_SEND/FS/
                      rm  /ETL1_QAD/_SEND/${preFileName} > /dev/null
                      ls ${dataDir}${preFileName} >> $log_file                                                           
                  fi 
        fi
fi
return 0 
}

# ��ȡ��һ���ʱ�䴮 
date_seg=`date +'%Y%m%d'`

get_predate_string $date_seg 

date_seg=$pre_date

get_predate_string $date_seg 

writelog " ---- Start link ----- "

# 1) link file  A01020*******

ln_func /etl1_data/BAD_CUST/_BACK/  A01020${city}${date_seg}\*   A01020${city}${pre_date}\* 
 

# 2) link file   A02904*****

ln_func /etl1_data/BAD_SERV/_BACK/  A02904${city}${date_seg}\*  A02904${city}${pre_date}\*
 

# 3) link file A02002*****

ln_func /etl1_data/BAD_SERV/_BACK/  A02002${city}${date_seg}\*    A02002${city}${pre_date}\* 
 

# 4) link file   I03013****

ln_func /etl1_data/BAD_MBR/_BACK/  I03013${city}${date_seg}\*   I03013${city}${pre_date}\* 
 

# 5)  link file  I08101*****

ln_func /etl1_data/BRD_CODE/_BACK/  I08101${city}${date_seg}\*  I08101${city}${pre_date}\*
 
# 6) link file I08924*****

ln_func /etl1_data/BRD_CODE/_BACK/  I08924${city}${date_seg}\*   I08924${city}${pre_date}\*  
 
# 7) link file I08923*****

ln_func  /etl1_data/BRD_CODE/_BACK/  I08923${city}${date_seg}\*  I08923${city}${pre_date}\* 
 
# 8) link file I08934*****

ln_func  /etl1_data/BRD_CODE/_BACK/  I08934${city}${date_seg}\*  I08934${city}${pre_date}\* 
 

writelog " ---- END -----"
writelog " "



