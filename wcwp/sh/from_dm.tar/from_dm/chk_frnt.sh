#!/bin/sh
if [ $# -ne 2 ]
then
echo "usage : xxx GZ cx_ant"
exit
fi

cd /ETL1_CX/etl/dssprog/loaddir/
dm=$1    
username=$2
./unloadtb.sh ${dm} 0 'select * from frnt.tn_file_download_log ' '&' 0 ${dm}.tn_file_download_log
grep ${username} /ETL1_CX/etl/dssprog/loaddir/${dm}.tn_file_download_log

