sqlplus zhengfengmei/oracle123@gzdm<<EOF
set heading off;
select table_name from all_tables where table_name like '%TO_CRUSER_RINGINFO%' and rownum<1000 order by table_name ;
describe ODS.TO_COLORING_USR_200810
select * from   ODS.TO_CRUSER_RINGINFO_200810 where rownum<10;
quit;
EOF

