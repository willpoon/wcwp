#!/bin/ksh
path=$1
cd $path

#for list file
for list_file in `ls *bill*.list`
do
grep -v 'cs' $list_file | awk -F'.' '{if(NF==3) {printf("%s.%s.01.%s\n",$1,$2,$3);} else print $0}'
>$list_file.tmp
mv $list_file.tmp $list_file
done

#for data file
for data_file in `ls | grep .Z`
do
fields=`echo $data_file | awk -F'.' '{print NF}'`
if [ $fields -eq 3 ] 
then
echo $data_file
new_name=`echo $data_file | awk -F'.' '{if(NF==3) {printf("%s.%s.01.%s",$1,$2,$3);} else print $0}'`
mv $data_file $new_name
fi
done

cd -
