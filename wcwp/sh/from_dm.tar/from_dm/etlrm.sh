#!/bin/ksh
#************************************************************************
#Function:\t remove too many file for dss
#Useage:\t usage:$0 'filelist expression'
#Useage:\t usage:$0 '/tmp/*'
#Author:\t Deng Chongwei
#*Version:\t 0.9.0
#modified history :
#v01.00.000	dengchongwei	���
#************************************************************************

errlog()
{
  format=`date +%Y-%m-%d"  "%H:%M:%S`"  Shell P_ID[$$]:"
  echo "$format $1"|tee -a ./etlrm.err.log 2>&1
}

if [ $# -ne 1 ]
then
  errlog "usage:$0 'filelist expression'"
  errlog "para error,please recall!"
  exit 1
fi


#�ж�BIPROG_ROOT�����Ƿ�����
if [ -z "$BIPROG_ROOT" ]
then
  errlog "Please set environment variable:BIPROG_ROOT"
  errlog "Or The directory:$BIPROG_ROOT/log don't exists."
fi

logfile=$BIPROG_ROOT/log/etlrm.log

log()
{
  format=`date +%Y-%m-%d"  "%H:%M:%S`"  Shell P_ID[$$]:"
  echo "$format $1">>$logfile 2>&1
}

log "BEGIN rm $1"

for file in $1
do
  rm $file>>$logfile 2>&1
  
  if [ $? -ne 0 ]
  then
    log "Warnning: rm $1 failed."
    exit 1
  fi
done

log "FINISH rm $1"
