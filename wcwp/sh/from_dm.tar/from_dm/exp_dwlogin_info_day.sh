#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.001
# 
# USAGE:
#	exp_dwlogin_info_day.sh 
# ϵͳÿ�յ��øýű��������ݼ���Ӧ�÷�Χ�ӿ�.
#     
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070607   NieJian           �½�

######################################################################

##AIX��ȡ����ʱ��
aaa=`echo $TZ|sed 's/.*\(..\)/\1/'`
aaa=`expr $aaa + 24`
eval aaa=`echo $TZ|sed 's/..$/+$aaa/'`
TZ=$aaa
export TZ
yy=`date +%Y`
mm=`date +%m`
dd=`date +%d`

datadate=$yy$mm$dd

##û�취,crontab���õ�һ���� /etc/passwd �ļ��еĵ�¼���ƣ������ܵ�ǰʵ��ʹ����һ����¼����
##��root�û�ʹ�ò���sqlplus
##ֻ��ʹ��ɵ�ϰ취��,��Ȼ,����root�û���/etc/passwd��etl�û���������λҲ��,����û����
##etl2
##export BIPROG_ROOT=/ETL2_CX/etl/dssprog
##etl1
export BIPROG_ROOT=/ETL1_CX/etl/dssprog
export ORACLE_BASE=/oracle/products
export ORACLE_HOME=$ORACLE_BASE/10.2/db
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib:/usr/local/lib
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:$BIPROG_ROOT/lib:$DB2HOME/lib
export LD_LIBRARY_PATH
LIBPATH=/usr/lib:$ORACLE_HOME/lib:$BIPROG_ROOT/lib:$DB2HOME/lib
export LIBPATH
PATH=/usr/bin:/usr/vacpp/bin::/usr/local/bin:/etc:/usr/sbin:/usr/ucb:/usr/bin/X11:/sbin:$ORACLE_HOME/bin:$BIPROG_ROOT/bin:/db2home/sqllib/bin
export PATH
export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK

##etl2
##for dataarea in SZ HZ MZ SG JY SW ZQ
##etl1
for dataarea in GZ ST ZS ZH QY HY CZ
do

###etl2
#filename1=/etl2_data/TRANSDATA/DWAD_CUST/yy_usrlogin_sjjs_${dataarea}.${datadate}
#filename2=/etl2_data/TRANSDATA/DWAD_CUST/yy_usrvst_sjjs_${dataarea}.${datadate}
###etl1
filename1=/etl1_data/TRANSDATA/DWAD_CUST/yy_usrlogin_sjjs_${dataarea}.${datadate}
filename2=/etl1_data/TRANSDATA/DWAD_CUST/yy_usrvst_sjjs_${dataarea}.${datadate}
filename3=/etl1_data/TRANSDATA/DWAD_CUST/yy_usr_inf_${dataarea}.${datadate}
filename4=/etl1_data/TRANSDATA/DWAD_CUST/yy_usr_authority_${dataarea}.${datadate}

sh $BIPROG_ROOT/bin/EXP_USRLOGIN.sh  ${datadate} ${dataarea} ${filename1}
sleep 10
sh $BIPROG_ROOT/bin/EXP_USRVST.sh  ${datadate} ${dataarea} ${filename2}
sleep 10
sh $BIPROG_ROOT/bin/EXP_USR_INF.sh  ${datadate} ${dataarea} ${filename3}
sleep 10
sh $BIPROG_ROOT/bin/EXP_USR_AUTHORITY.sh  ${datadate} ${dataarea} ${filename4}
sleep 10
done

