sqlplus zhengfengmei/oracle123@gzdm<<EOF

select table_name from all_tables where table_name like '%TO_MULTNBR_REL%' and rownum<1000 order by table_name ;
select table_name from all_tables where table_name like '%SRV_TYP%' and rownum<1000 order by table_name ;
select table_name from all_tables where table_name like '%TR%REA%' and rownum<1000 order by table_name ;
describe ref.TR_dir_typ ;

describe ref.TR_SRV_TYP;
select * from ref.TR_SRV_TYP order by 1;

select * from ods.TO_MULTNBR_REL_MO_200810 where rownum<3;
quit;
EOF



