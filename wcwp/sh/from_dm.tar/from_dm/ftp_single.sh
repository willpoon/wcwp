#!/bin/sh

ftp -in $1<<END
user etl etl
lcd $2
cd $3
bin
put $4
quit
END
