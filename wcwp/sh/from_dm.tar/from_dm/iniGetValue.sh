#!/bin/sh
##############################################################################
# FILENAME: iniGetValue.sh
# VERSION:  V01.00.000
# PURPOSE:  Read data from INI file
# USAGE:    iniGetValue.sh <inifile> <section> <valueid>
# AUTHOR:   ������
# HISTORY:
# ����      �汾        �޸���      �޸ļ�¼
# --------- ----------- ----------- ------------------------------------------
# 20041221  V01.00.000  ������      �½��ű�
#
##############################################################################

if [ $# -ne 3 ];then
    echo "usage: iniGetValue <inifile> <section> <valueid>" 1>&2
    exit 1
fi

inifile=$1
section=$2
valueid=$3

awk -F= 'BEGIN { retval = 1 }
 {
    if (substr($0, 1, 1) == "[")
         valid = 0;
    if ($1 == "['$section']")
    {
        valid = 1;
    }
    else if (valid == 1)
    {
        if ($1 == "'$valueid'")
        {
            print $2;
            retval = 0;
            exit;
        }
    }
 } END {exit retval}' "$inifile"

