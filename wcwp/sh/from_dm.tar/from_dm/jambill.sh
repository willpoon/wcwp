#!/bin/ksh
echo "
*************************************************************************
*Function: ���ʵ��ļ�����
*Version:\t 01.00.000
*Author: Xiao Zhangwu
*************************************************************************"
#if [ $# -ne 1 ]
#then
#   echo "Please enter the {Month} ."
#   exit 1
#fi

HOMEDIR=`dirname $0`
if [ "${HOMEDIR}" = "." ]
then
        HOMEDIR=`pwd`
fi

hostn=`hostname| awk '{print "etl"substr($0,8,1)}'`
DATAPATH=/${hostn}_data/JAM_BILL/_EXF/

cd ${DATAPATH}


###############################����list�ļ�####################################
rm *.list.bak

for listfile in `ls *.list`
do
    cp ${listfile} ${listfile}.bak
done

for fi in `ls  *.list.bak`
do
   grep -v "cs.Z" ${fi} | awk '{if(length($2) == 13){$2=substr($2,1,11)".01.Z"}print $0}' > ${fi%.bak}
done  

for fi in `ls  *.list.bak`
do
   grep  "cs.Z" ${fi} | awk '{if(length($2) == 16){$2=substr($2,1,11)".01.cs.Z"}print $0}' > ${fi%.list.bak}.cs.list
done

################################�����ļ���#######################################
#1. ��cs�ļ�
for fi in ` ls -l | grep -v "cs\.Z" | grep -v "list" | awk '{if(length($9) == 13){print $9}}' `
do
   mv ${fi} ${fi%.Z}.01.Z
done

#2. cs�ļ�
for fi in ` ls -l | grep  "cs\.Z" |awk '{if(length($9) == 16){print $9}}' `
do
    mv ${fi} ${fi%.cs.Z}.01.cs.Z
done




