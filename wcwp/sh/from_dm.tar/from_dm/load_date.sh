for date in 200802
do
sh ./load.sh $date $1
done
