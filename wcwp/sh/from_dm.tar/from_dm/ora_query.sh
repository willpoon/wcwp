#!/bin/ksh
#################################################################
# FILENAME: query.sh
# VERSION:  V01.00.000
# USAGE:
# AUTHOR:   xyb/200708
# HISTORY:
# modify                        xyb/20070822
# modify                        xyb/20071123
#������ʵ������                 xyb/20080311
#################################################################

if [ -f .ora_xyb_tmp_*sql ]
then
rm .ora_xyb_tmp_*sql 
fi

if [ ! -d _log ]
then
   mkdir _log
fi

#д��־
logfile=_log/runsql

####################################################
run_sql()
{
vi _run_sql_tmp_$$.sql
echo '-----------------------------------'
head  _run_sql_tmp_$$.sql
echo ......
print "�Ƿ�ִ��SQL [y|n]��"
read FF
if [ "${FF}" = "y" ]
then
print "������������ݿ�[��:gzdm(������У��ո�ֿ�)|���е���������:all]��"
read DB
if [ "${DB}" = "all" ]
then
DB="GZDM SZDM STDM ZHDM HZDM ZSDM SGDM HYDM QYDM CZDM JYDM MZDM SWDM ZQDM" 
fi

echo ${DB} |grep -i [a-z][a-z]dm >/dev/null
if [ $? -eq 1 ] >/dev/null
then
echo "���������˳�..."
exit 0
fi

for db in ${DB}
do
   echo "###-- ${db} --###" |tee -a ${logfile}_$$.log
      sqlplus -S etl/bi96123etl@${db} <<EOF
      set pagesize 500;
      set linesize 138;
      set echo on;
      spool ${logfile}_$$.log append;
start _run_sql_tmp_$$;
exit;

EOF
     done
     if [ ! -d _back ]
     then
        mkdir _back
     fi
     
     mv _run_sql_tmp_$$.sql _back/
     echo "###-- �����־��${logfile}_$$.log --###"
     egrep "ORA|##" ${logfile}_$$.log
fi
}
######################################
_sqlplus()
{
print "������������ݿ�[��:gzdm(������У��ո�ֿ�)|���е���������:all]��"
read DB
if [ "${DB}" = "all" ]
then
DB="GZDM SZDM STDM ZHDM HZDM ZSDM SGDM HYDM QYDM CZDM JYDM MZDM SWDM ZQDM" 
fi

echo ${DB} |grep -i [a-z][a-z]dm >/dev/null
if [ $? -eq 1 ]  >/dev/null
then
echo "���������˳�..."
exit 0
fi

echo ###-- SQL --###
cat  .ora_xyb_tmp_$$.sql
for db in ${DB}
do
      echo "###-- ${db} --###"
      sqlplus -S etl/bi96123etl@${db}<<EOF
      set pagesize 500;
      set linesize 138;
start .ora_xyb_tmp_$$.sql;
exit;
EOF
done

}

#######################################
echo "###########################-- ��ѡ�� --###########################"
echo " 1.��ѯ��DBA_TABLES     2.��ѯ����DBA_INDEXES  3.��ѯԼ��DBA_IND_COLUMNS  4.��ѯ����վDBA_RECYCLEBIN  5.��ѯ����DBA_OBJECTS  "
echo "11.�鿴Oracle����ļ�  12.�鿴���ռ�(ʹ��80%) 13.�鿴�����DBA_SEGMENTS  14.�鿴��ǰ�ỰV\$SESSION    15.�鿴�ع���V\$ROLLSTAT " 
echo "21.DBA_TAB_PARTITIONS  22.DBA_IND_PARTITIONS  23.�鿴DBA_TABLESPACES     24.�鿴DBA_DATA_FILES       25.�鿴�����DBA_LOBS "
echo "31.ִ��SQL�ű�|����    32.�������ɿ�ִ��SQL   33.SQL���ɿ�ִ��SQL"  
echo ""
print "����ѡ����[q�˳�]: "
read type
case $type in
    1)
    print  "1.��ѯ dba_tables   ������ %table_name% | tablespace_name �� "
    read table_name
    print " col LOGGING for a7;
            col owner for a8;
            select owner, table_name, tablespace_name, STATUS, COMPRESSION, LOGGING, PARTITIONED, 
                   round(NUM_ROWS/10000,0) NUM_ROWS_W, TO_CHAR(LAST_ANALYZED,'yy-mm-dd hh24:mi:ss') LAST_ANALYZED
            from dba_tables where tablespace_name = '${table_name}' or table_name like '%${table_name}%'
            order by table_name;\n" |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    2)
    print  "2.��ѯ dba_indexes  ������ %table_name% | index_name | tablespace_name �� "
    read table_name
    print " col owner for a6
            col TABLESPACE_NAME for a22
            col INDEX_TYPE for a12
            select owner, index_name, table_name, tablespace_name, STATUS, INDEX_TYPE,
                   TO_CHAR(LAST_ANALYZED,'yy-mm-dd hh24:mi:ss') LAST_ANALYZED
            from dba_indexes
            where index_name = '${table_name}' or table_name like '%${table_name}%' or tablespace_name = '${table_name}'
            order by table_name;\n"   |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    3)
    print  "3.��ѯ dba_ind_columns  ������ table_name | index_name �� "
    read _name
    print " col COLUMN_NAME for a40;
            col index_owner for a10;
            select  column_name, COLUMN_LENGTH, index_name, table_name, index_owner
            from dba_ind_columns where INDEX_NAME='${_name}' or table_name='${_name}'
            order by COLUMN_POSITION;\n" |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    4)
    print "4.��ѯ DBA_RECYCLEBIN  ������ %table_name% | %tablespace_name%: "
    read _name
    print " col OWNER for a10;
            col CAN_UNDROP for a10;
            col TYPE for a20;
            col TS_NAME for a22;
            select OWNER, ORIGINAL_NAME, TYPE, TS_NAME, CREATETIME, DROPTIME, CAN_UNDROP
            from DBA_RECYCLEBIN where ORIGINAL_NAME like '${_name}%' or TS_NAME like '%${_name}%'
            order by DROPTIME desc ;\n" |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    5)
    print "5.��ѯ���� DBA_OBJECTS   ������ object_name% : "
    read object_name
    print " col OWNER for a6;
            col OBJECT_NAME for a30;
            select distinct a.OWNER, a.OBJECT_NAME, b.TABLESPACE_NAME, a.OBJECT_TYPE,TO_CHAR(a.CREATED,'yy-mm-dd hh24:mi:ss') CREATED,
                   TO_CHAR(a.LAST_DDL_TIME,'yy-mm-dd hh24:mi:ss') LAST_DDL_TIME, STATUS 
            from dba_objects a, DBA_SEGMENTS b
            where OBJECT_NAME like '${object_name}%' and a.OBJECT_NAME=b.SEGMENT_NAME(+)
            and a.OWNER=b.OWNER ;\n"  |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    ##################################
    11)
    echo "11.�鿴Oracle����ļ�"
    print " 
            col NAME for a65;
            col IS_RECOVERY_DEST_FILE for a22;
            select STATUS, BLOCK_SIZE*FILE_SIZE_BLKS/1024/1024 SIZE_M, NAME, IS_RECOVERY_DEST_FILE  from v\$controlfile;
            
            col MEMBER for a65;
            col ARCHIVED for a8;
            select a.GROUP#, a.TYPE, b.STATUS, b.BYTES/1024/1024 BYTES_M, a.MEMBER, b.ARCHIVED 
            from v\$logfile a, v\$log b where a.GROUP#=b.GROUP# ;          

            col FILE_NAME for a65;
            select TABLESPACE_NAME, STATUS, BYTES/1024/1024 SIZE_M, FILE_NAME from dba_temp_files;
            
            col NAME for a40;
            col VALUE for a65;
            select NAME, VALUE from v\$parameter where value like '%/%' and name != 'control_files' ; 
            "  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
   _sqlplus
   ;;
    12)
    echo "5.�鿴���ռ����(ʹ����>80%)"
    print " select c.tablespace_name, c.SUM_GB, c.FREE_GB, c.USE_PRECENT from (
            select b.tablespace_name,round((sum(b.bytes)/1024/1024/1024),3) SUM_GB,
            round((sum(nvl(a.bytes,0))/1024/1024/1024),3) FREE_GB,round((sum(b.bytes)-sum(nvl(a.bytes,0)))/sum(b.bytes),4)*100
            USE_PRECENT  from (select tablespace_name,file_id,sum(bytes) bytes from dba_free_space
            group by tablespace_name,file_id ) a,  dba_data_files b
            where a.file_id(+)=b.file_id and a.tablespace_name(+)=b.tablespace_name
            group by b.tablespace_name ) c
            where USE_PRECENT>80 order by USE_PRECENT; \n"  |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
   _sqlplus
   ;;
    13)
    print "13.�鿴�����С  ������ segment_name% | tablespace_name ��"
    read segment_name
    print " col SEGMENT_NAME for a30;
            col OWNER for a8;
            col SEGMENT_TYPE for a22;
            select a.OWNER, a.SEGMENT_NAME, a.TABLESPACE_NAME, a.SEGMENT_TYPE, a.SUM_BYTES_MB, b.COMPRESSION
            from (select OWNER,SEGMENT_NAME,TABLESPACE_NAME,SEGMENT_TYPE,SUM_BYTES_MB
            from (select OWNER, SEGMENT_NAME, TABLESPACE_NAME, SEGMENT_TYPE, round((sum(bytes)/(1024*1024)),2) SUM_BYTES_MB
            from dba_segments where SEGMENT_NAME like '${segment_name}%' or TABLESPACE_NAME='${segment_name}'
            group by OWNER, SEGMENT_NAME, TABLESPACE_NAME, SEGMENT_TYPE order by SUM_BYTES_MB desc )
            where rownum<101 )a, dba_tables b
            where b.TABLE_NAME(+)=a.SEGMENT_NAME and b.OWNER(+)=a.OWNER and b.TABLESPACE_NAME(+)=a.TABLESPACE_NAME  
            order by SUM_BYTES_MB;\n "  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
   _sqlplus
   ;;
    14)
    print "14.�鿴��ǰ�ỰV\$SESSION  "
    print " col USERNAME for a8;
            col MACHINE for a10;
            col EVENT for a40;
            col WAIT_CLASS for a13;
            select a.SID, a.SERIAL#, b.QCSID, a.USERNAME, a.MACHINE, a.STATUS, a.WAIT_CLASS, a.EVENT,
                   TO_CHAR(a.LOGON_TIME,'yy-mm-dd hh24:mi:ss') LOGON_TIME 
            from v\$session a, v\$px_session b where a.SID=b.SID(+) and a.USERNAME != 'null'
            order by LOGON_TIME; \n"  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    15)
    print "15.�鿴�ع���V\$ROLLSTAT  "
    print " col tablespace_name for a22;
            col SEGMENT_NAME for a22;
            select a.tablespace_name,a.SEGMENT_NAME,a.SEGMENT_ID,b.LATCH,
                   b.EXTENTS,a.MAX_EXTENTS,b.XACTS,b.STATUS
            from dba_rollback_segs a,v\$rollstat b  where XACTS<>0
            and a.SEGMENT_ID = b.USN order by SEGMENT_ID;\n"  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    ##################################
    21)
    print  "21.��ѯ dba_tab_partitions   ������ %table_name% | tablespace_name �� "
    read table_name
    print " col TABLE_OWNER for a11;
            col PARTITION_NAME for a22;
            select TABLE_OWNER, table_name, PARTITION_NAME, tablespace_name, COMPRESSION, round(NUM_ROWS/10000,0) NUM_ROWS_W, LAST_ANALYZED
            from dba_tab_partitions where tablespace_name = '${table_name}' or table_name like '%${table_name}%'
            order by table_name, TABLESPACE_NAME;\n" |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    22)
    print  "22.��ѯ dba_ind_partitions  ������ %index_name% | tablespace_name �� "
    read index_name
    print " col INDEX_OWNER for a11;
            col TABLESPACE_NAME for a22;
            col PARTITION_NAME for a22;
            select INDEX_OWNER, index_name, PARTITION_NAME, TABLESPACE_NAME, COMPRESSION, STATUS, round(NUM_ROWS/10000,0) NUM_ROWS_W, LAST_ANALYZED
            from dba_ind_partitions where index_name  like '%${index_name}%' or tablespace_name = '${index_name}'  
            order by index_name, LAST_ANALYZED ;\n"   |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    23)
    print  "23.��ѯ dba_tablespaces  "
    print " col DEF_TAB_COMPRESSION for a20;
            col ALLOCATION_TYPE for a16;
            select a.TABLESPACE_NAME, STATUS, BLOCK_SIZE/1024 BLOCK_SIZE_M, 
                   ALLOCATION_TYPE, DEF_TAB_COMPRESSION, LOGGING, SUM_SIZE_G 
            from dba_tablespaces a,(select TABLESPACE_NAME,  round(SUM(BYTES)/1024/1024/1024,2)  SUM_SIZE_G 
                                    from dba_data_files group by TABLESPACE_NAME ) b 
            where a.TABLESPACE_NAME=b.TABLESPACE_NAME 
            order by TABLESPACE_NAME;\n"  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    24)
    print  "24.��ѯ dba_data_files  ������ tablespace_name% | all "
    read tablespace_name
    if [ ${tablespace_name} = "all" ]
    then
    print " col FILE_NAME for a65;
            select TABLESPACE_NAME, STATUS, BYTES/1024/1024 SIZE_M, FILE_NAME, ONLINE_STATUS 
            from dba_data_files order by TABLESPACE_NAME,FILE_NAME;\n"   |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    else
    print " col FILE_NAME for a65;
            select TABLESPACE_NAME, STATUS, BYTES/1024/1024 SIZE_M, FILE_NAME, ONLINE_STATUS 
            from dba_data_files where TABLESPACE_NAME like '${tablespace_name}%' 
            order by TABLESPACE_NAME,FILE_NAME; \n " |tr "[a-z]" "[A-Z]" |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    fi
    _sqlplus
    ;;
    25)
    print "25.�鿴�����DBA_LOBS  ������ %table_name% | tablespace_name ��"
    read segment_name
    print "  col COLUMN_NAME for a30
             select OWNER, TABLE_NAME, COLUMN_NAME, TABLESPACE_NAME from dba_lobs
             where TABLESPACE_NAME='${segment_name}' or TABLE_NAME like '%${segment_name}%'
             order by TABLE_NAME ; \n"  |sed 's/  */ /g' > .ora_xyb_tmp_$$.sql
    _sqlplus
    ;;
    ##################################
    31)
    run_sql
    ;;
    32)
    echo "32.�������ɿ�ִ��SQL(vi�༭)[y|n]: "
    read _IN
    if [ ${_IN} == "y" ]
    then
        
    echo >.ora_xyb_tmp_$$_all.sql
    vi .ora_xyb_tmp_$$_all.sql
    echo
    cat  .ora_xyb_tmp_$$_all.sql
    print "\n������������ݿ�[��:gzdm(������У��ո�ֿ�)|���е���������:all]��"
    read DB
    if [ "${DB}" = "all" ]
    then
    DB=" GZDM SZDM STDM ZHDM HZDM ZSDM SGDM HYDM QYDM CZDM JYDM MZDM SWDM ZQDM "
    fi

    echo ${DB} |grep -i [a-z][a-z]dm >/dev/null
    if [ $? -eq 1 ]  >/dev/null
    then
    echo "���������˳�..."
    exit 0
    fi

    for CC in ${DB} 
    do
    echo "sqlplus -S etl/bi96123etl@${CC} <<!" >_sql/${CC}_$$.sh
    cat .ora_xyb_tmp_$$_all.sql  >>_sql/${CC}_$$.sh
    echo "!"   >>_sql/${CC}_$$.sh
    echo "sh _sql/${CC}_$$.sh >_sql/${CC}_$$.sh.log & " 
    done
    
    else 
    echo "��֤������˳�"    
    fi
    ;;
    33)
    echo "33.SQL���ɿ�ִ��SQL(vi�༭)[ZZ�����˳�] ��������֤�룺$$"
    read _IN
    if [ ${_IN} == "$$" ]
    then

    echo >.ora_xyb_tmp_$$_all2.sql
    vi .ora_xyb_tmp_$$_all2.sql
    echo
    cat  .ora_xyb_tmp_$$_all2.sql

    print "\n������������ݿ�[��:gzdm(������У��ո�ֿ�)|���е���������:all]��"
    read DB
    if [ "${DB}" = "all" ]
    then
    DB=" GZDM SZDM STDM ZHDM HZDM ZSDM SGDM HYDM QYDM CZDM JYDM MZDM SWDM ZQDM " 
    fi

    echo ${DB} |grep -i [a-z][a-z]dm >/dev/null
    if [ $? -eq 1 ]  >/dev/null
    then
    echo "���������˳�..."
    exit 0
    fi

    for CC in ${DB} 
    do
    echo "sqlplus -S etl/bi96123etl@${CC} <<!" >_sql/${CC}_2_$$.sh

    sqlplus -S  etl/bi96123etl@${CC} <<EOF
    
    SET TERMOUT off
    set echo off
    set head off
    set feedback off
    set pagesize 500
    set linesize 138
    
    spool _sql/${CC}_2_$$.sh APPEND
    @.ora_xyb_tmp_$$_all2.sql
    spool off
EOF
    
    echo "!"   >>_sql/${CC}_2_$$.sh
    
    echo "sh _sql/${CC}_2_$$.sh >_sql/${CC}_2_$$.sh.log & "
    done
 
    else 
    echo "��֤������˳�"
    fi
    ;;
    q|Q)
    exit 1
    ;;
    *)
    echo  "���������,��˲�!"
    exit 1
    ;;
esac
#################### END ####################

