#!/bin/ksh
#####################################################
# Function: Get DDL for tables
# Parameter:
#	-d db -i user -w pwd -t table1[,table2,table3...] -o outfile
#
#	eg: oralook.sh -d gzdm -i etl -w etl -t TABLE1,TABLE2 -o table.sql
#
######################################################

VERSION="V1.00.000"


# Parse parameters
while getopts d:i:w:t:o: opt
do
	case $opt in
	d) dbname=$OPTARG;;
	i) username=$OPTARG;;
	w) password=$OPTARG;;
	t) tables=$OPTARG;;
	o) outfile=${OPTARG%.sql}.sql;;
	*) echo -e "VERSION:$VERSION\nUsage:$0 -d db -i user -w pwd -t table1[,table2,table3...] -o outfile[.sql]"
		exit 255;;
	esac
done

if [[ -z $dbname || -z $username || -z $tables || -z $outfile ]]
then
	echo -e "VERSION:$VERSION\nUsage:$0 -d db -i user -w pwd -t table1[,table2,table3...] -o outfile[.sql]"
	exit 255
fi

if [ $OPTIND -eq 8 ]
then
	echo -c "Please input password:"
	read password
fi



dbinfo="$username/$password@$dbname"
exptemp="/tmp/exp_`date +%Y%m%d%H%M%S`.tmp"

# call exp to export ddl for tables
exp $dbinfo file=$exptemp "tables=($tables)" rows=n grants=n statistics=none indexes=y triggers=y

#if [ $? -ne 0 ]
#then
#	echo "-----------------------------------------------------"
#	echo "Have Error! Please Check."
#	rm $exptemp 2>/dev/null
#	exit 255
#fi


# get table's ddl by call imp
imp $dbinfo touser=etl file=$exptemp "tables=($tables)" show=y indexes=y constraints=y indexfile=$outfile 


rm $exptemp


# post-process
perl -i -pe 's/^REM //' $outfile
perl -i -pe 's/^.*?\d+\srows.*$//' $outfile
perl -i -pe 's/"//g' $outfile

exit 0
