sqlplus zhengfengmei/oracle123@gzdm<<EOF

set colsep ,
set echo off
set feedback off
set heading off
set pagesize 0
set linesize 32767
set numwidth 30
set termout off
set timing off
set trimout on
set trimspool on
spool /gmcc_data/gz/zhengfm/jianglw/outdata/spool_to_playbar_acct_cnsmday_out.dat;
select * from ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809 order by 1;
spool off;

exit;
EOF
sed 's/ //g' /gmcc_data/gz/zhengfm/jianglw/outdata/spool_to_playbar_acct_cnsmday_out.dat>/gmcc_data/gz/zhengfm/jianglw/outdata/spool_to_playbar_acct_cnsmday_out.txt
