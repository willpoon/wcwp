#!/usr/bin/sh
#################################################################
# FILENAME: sqlldr.sh
# VERSION:  V01.00.000
# USAGE:
# AUTHOR:   xyb/200803
# HISTORY:
# CREATE                     xyb/20080401
# MODIFY                     xzw/20081210 add "BINDSIZE=20971520 READSIZE=20971520 STREAMSIZE=20971520"

#################################################################
if [ $# -ne 4 ]
then
echo "Usage: $0 <dbname> <table> <datafile> <'colsep'> "
exit
fi

################################################################################
## ���������
dbname=$1
table=$2
infile=$3
colsep=$4
username=etl
password=`grep GZpassword  ~etl/dssprog/config/prog.ini |sed 's/GZpassword=//g'`
#printf "Enter ${username} password: "
#read  password

userid="${username}/${password}@${dbname}"
badfile="${dbname}_${table}_$$.bad"
lv_control="`echo ${dbname}`_${table}_$$"
cat /dev/null >${lv_control}

sqlplus  $userid<<EOF>/dev/null
        spool ${lv_control}.tmp;
        desc ${table};
        spool off;
        exit;
EOF

if [ $? -ne 0 ]
then
        echo "Error: error in generate control file for table ${table} !"
        echo "Usage: sqlldr.sh <dbname> <table> <datafile> <'colsep'>"
        exit
fi

##ȷ�����Ƿ����
str_tmp=`grep 'ERROR' ${lv_control}.tmp |sed 's/ //g'`

if [ "${str_tmp}" != '' ]
then
      echo "${table} not exist!"
      return -1
fi

##��������10000
if [ -f ${infile} ]
then
errors=10000
fi

##���ɿ����ļ�
if [ -f ${lv_control}.tmp ]
then
        cat ${lv_control}.tmp |grep -v ">" |grep -v "Name" |grep -v "\-\-\-\-\-\-\-\-"  |grep -v "^ *$" > ${lv_control}
        rm -f ${lv_control}.tmp 

        lv_str="LOAD DATA INFILE '${infile}' BADFILE '${badfile}' APPEND INTO TABLE ${table} FIELDS TERMINATEd BY '${colsep}' TRAILING NULLCOLS "
        echo ${lv_str} >${lv_control}.ctl
        echo "("  >>${lv_control}.ctl

        lv_line_num=`wc -l ${lv_control} |awk '{print $1}'`
        if [ ${lv_line_num} -gt 1 ]
        then
        lv_index=`expr ${lv_line_num} - 1`
        awk '{print $1}' ${lv_control} |sed -n "1,${lv_index}p"  |sed  's/$/,/g' >>${lv_control}.ctl
        awk '{print $1}' ${lv_control} |sed -n ${lv_line_num}p  >>${lv_control}.ctl
        else
        awk '{print $1}' ${lv_control} |sed -n ${lv_line_num}p  >>${lv_control}.ctl
        fi

        echo ")" >>${lv_control}.ctl
        rm -f ${lv_control}

else
        echo "$0 error :not find ${lv_control} file."
        exit
fi

##ִ��װ��
sqlldr ${userid} control=${lv_control}.ctl BINDSIZE=10240000  ROWS=500000 ERRORS=${errors} LOG="${lv_control}.log"
#10240000
rm ${lv_control}.ctl

echo 
grep 'Rows successfully loaded' ${lv_control}.log
grep 'Total logical records read' ${lv_control}.log

########################## END ########################

