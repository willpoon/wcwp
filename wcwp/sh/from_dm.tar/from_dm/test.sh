sqlplus zhengfengmei/oracle123@gzdm<<EOF
set heading off;
select table_name from all_tables where table_name like '%TO_PLAYBAR_ACCT%' and rownum<1000 order by table_name ;
describe ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809;
select count(*) from  ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809;
select count(*) from  ODS.TO_PLAYBAR_usr_CNSM_DAY_200809; 
select TM_INTRVL_CD,count(*) from  ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809 group by  TM_INTRVL_CD order by 1;
select TM_INTRVL_CD,count(*) from  ODS.TO_PLAYBAR_usr_CNSM_DAY_200809 group by  TM_INTRVL_CD order by 1;
select TM_INTRVL_CD,count(*) from  ODS.TO_PLAYBAR_ACCTCHRG_DAY_200809 group by  TM_INTRVL_CD order by 1;
      
elect sp_code,sp_subbusi_cd,count(*) from  ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809 group by sp_code,sp_subbusi_cd order by 1,2;
set linesize 1000;
select * from ODS.TO_PLAYBAR_ACCT_CNSMDAY_200809 where rownum<10;
--select view_name from all_views where view_name like '%IUSR%' and rownum<1000;
quit;
EOF

