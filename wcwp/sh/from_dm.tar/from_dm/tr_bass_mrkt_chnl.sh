#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#	mrkt_chnl.sh  <city><date>
# 
# 
# PARAMETERs:
#     
#      city        ������
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20081224  huangkenglong    ��oracle���ݿ��е�������ά����db2��ȥ
                              
######################################################################
if [ $# -ne 2 ]
then
  echo "Usage:$0  <city><date>"
  exit 1
fi

#�ж�BIPROG_ROOT�����Ƿ�����
if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi


logfile=$BIPROG_ROOT/log/tr_bass_mrkt_chnl.log

writelog()
{
  echo "P_ID[$$]:"`date "+%Y-%m-%d %H:%M:%S"`" "$1 >>$logfile
}

city=$1
date=$2

writelog "-------------start to update the REF.TR_BASS_MRKT_CHNL-----------------------"

#���������ݿ⵼��ά������
tmppipe="/tmp/TR_BASS_MRKT_CHNL_${city}.txt"

writelog "file: ${tmppipe}"

mknod ${tmppipe} p
unloadtb.sh ${city} ${date} "select * from  ref.TR_BASS_MRKT_CHNL" "&" 0  $tmppipe >>$logfile
cat /tmp/TR_BASS_MRKT_CHNL_${city}.txt >>/tmp/REF.TR_BASS_MRKT_CHNL.TXT
rm -f ${tmppipe}







# 2007-05-21 �������޸ģ���Ϊ�ϸ�ͨ��section���ӱ�������ini�ļ�
iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName db2 password`


writelog "Connecting to database ($dbname)..."
db2 connect to $dbname user $dbuser using $dbpasswd >/dev/null
    retcode=$?
if [ $retcode -ne 0 ]
then
  writelog "connect to $dbname Failed."
  exit 1
fi


cmd="IMPORT from  /tmp/REF.TR_BASS_MRKT_CHNL.TXT of del modified by coldel& COMMITCOUNT 50000 INSERT_UPDATE into REF.TR_BASS_MRKT_CHNL " 
writelog "$cmd"
db2 "$cmd" >>$logfile
db2 terminate
rm -f /tmp/REF.TR_BASS_MRKT_CHNL.TXT

writelog "-------------end to update the TR_BASS_MRKT_CHNL-----------------------"
