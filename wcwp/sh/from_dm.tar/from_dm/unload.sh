#!/bin/sh
###############################################################################
# FILENAME: 
# VERSION : 01.00.002
# 
# USAGE:
#       db2_load.sh  <dataarea> <full_file_name>  <sql_str>
# 
# 
# PARAMETERs:
#     tablename      Ҫ����ı�
#     filepath        export��ʱĿ¼
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070522  zhengjiecong           �½�
# 200706052  NieJian         o �޸��˶�INI�ļ��Ĵ��룬��Ϊʹ��iniGetValue.sh
#                            o ԭ����ֱ��д|tee -a $logfile�ᵼ���޷�������
#                              �޸�֮
#                            o �޸Ĳ���,�������ļ��ж�ȡ�û���/����,����д��
# 20080410  quanchao           �޸���ɾ���������ļ���sqlplus�в�����etl@��
######################################################################


# д��־��shell����
logfile=$BIPROG_ROOT/log/`basename $0`.log
writelog()
{
  echo `date "+%Y-%m-%d %H:%M:%S"`" $1" | tee -a $logfile
}

if [ $# -ne 3 ]
then
        echo "Usage:$0  <dataarea> <full_file_name>  <sql_str>"
        writelog "Usage:`basename $0` user/pass@database export_file sql"
exit 1
fi


dataarea=$1
fname=$2
ex_tbl=$3

#section���ӱ�������ini�ļ�

if [ -z "$BIPROG_ROOT" ]
then
  echo "Shell P_ID[$$]:Please set environment variable:BIPROG_ROOT"
  exit 1
fi
iniFileName=$BIPROG_ROOT/config/prog.ini
dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}dbname`
dbuser=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}username`
dbpasswd=`$BIPROG_ROOT/bin/iniGetValue.sh $iniFileName oracle ${dataarea}password`

usrid=${dbuser}/${dbpasswd}@${dbname}



writelog "export file $fname begin"
writelog "export sql :$ex_tbl"
tmpdir=$BIPROG_ROOT/tmp
fname2=$tmpdir/$$`basename $fname`2
fname3=$tmpdir/$$`basename $fname`3
writelog "$fname2"

writelog "export $table start"
sqlplus $usrid <<EOF >/dev/null
 set COLSEP |;
 set echo off;
 set heading off ;
 set feedback off;
 set pagesize 0 ;
 set linesize 2000;
 set termout off;
 set trimout on;
 set trimspool on;
 spool ${fname2};
 $ex_tbl
 spool off ;
exit
EOF

if [ "$?" -ne 0 ] ; 
then 
 echo "Error:sqlplus $userid error in unload table $table!! "
 echo "Please check userid and passwd or database." 
 exit  
fi 

writelog "export $table success, wait���������������� "
## sed  -e '/^SQL>/d' -e '/^$/d' $fname2 >$fname3
##sed  -e '/^SQL>/d' -e '/^$/d' -e 's/ *\| */\|/g' $fname2 >$fname3
 sed  -e '/^SQL>/d' -e '/^$/d' -e 's/ *\| */\|/g' -e '/^etl@/d' $fname2 >$fname3

rm $fname2

mv $fname3 $fname
fname4="${fname}.Z"
rm $fname4
cnt2=`wc -l $fname |awk '{print($1)}'`
writelog "export $cnt2 rows "
writelog "export $fname end "
