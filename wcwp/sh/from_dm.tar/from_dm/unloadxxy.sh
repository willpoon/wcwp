#!/bin/sh
###############################################################################
# FILENAME:
# VERSION : 01.00.002
#
# USAGE:
#       unloadtb.sh area_id date sqlstmt sign compress_type  outputfile  
#
# PARAMETERs:
#     userid     ��½���ݿ��û����� 
#     sqlstmt    ��Ҫ������sql���
#     file       ����ļ�
#     sign       ���ݷָ����
#     compress_type 0 uncompress 1 .Z  2.gz
#     date   is unused
# HISTORY:
# Date      Author          Description
# ----------------------------------------------------------------------------
# 20070924   xiaoqingyuan   �½����ļ�
# 20080124   xiaoqingyuan   �޸���ʾ���뷽ʽ
# note:tmpdir /etl1_data/TRANSDATA/TMP
######################################################################

export LIBPATH=$ORACLE_HOME/lib32
export LD_LIBRARY_PATH=$ORACLE_HOME/lib32

if [ $# -ne 6 ]
then
	echo "Usage:$0 area_id date sqlstmt sign compress_type  outputfile "
	exit 1	
fi

area_id=$1
date_id=$2
sqlstmt_id=$3
sign=$4
compress_type=$5
outputfile=$6

filedir=`dirname ${outputfile}`
if [ ${filedir} = "." ]
then
        outputfile=$BIPROG_ROOT"/loaddir/"${outputfile}
fi

#get login info 
#dbname=`$BIPROG_ROOT/bin/iniGetValue.sh $BIPROG_ROOT/config/prog.ini oracle ${area_id}dbname`
#username=`$BIPROG_ROOT/bin/iniGetValue.sh $BIPROG_ROOT/config/prog.ini oracle ${area_id}username`;
#password=`$BIPROG_ROOT/bin/iniGetValue.sh $BIPROG_ROOT/config/prog.ini oracle ${area_id}password`;

#logfile="$BIPROG_ROOT/log/"$0".log"
appname=`basename $0`
logfile="$BIPROG_ROOT/log/"${appname}".log"

pdate=`date`
echo "start time:"$pdate >>$logfile
echo "begain to process ..." >>$logfile

#area_id="userid="${username}"/"$password"@"${dbname}
dbname="dbname="${area_id}

inifile="inifile="${BIPROG_ROOT}"/config/prog.ini"
sqlstmt_id="sqlstmt="${sqlstmt_id}
sign="sign="${sign}

echo "${sqlstmt_id}" >>$logfile
echo ${sign} >>$logfile

#change file
#`basename $0`
tmpfile="/ETL1_QAM1/load/"`basename ${outputfile}`

echo "tmpfile : "${tmpfile} >>$logfile
echo "start to load ...." >>$logfile

plog1="/ETL1_QAM1/load/"${dbname}`basename ${outputfile}`".log"
plog="log="${plog1}
echo "hide log:" $plog>>$logfile

#unloadtb ${area_id} "${sqlstmt_id}"  ${sign} ${plog} >${tmpfile}
unloadtb ${inifile} ${dbname} "${sqlstmt_id}"  ${sign} ${plog} >${tmpfile}

cat ${plog1} >>$logfile
rm ${plog1}

echo "load finish!" >>$logfile

case ${compress_type} in
0)     
	mv -f  ${tmpfile}  ${outputfile}
	echo "mv -f  "${tmpfile}"  "${outputfile} >>$logfile
	break;;
1)
	echo "start to compress "${tmpfile} >>$logfile
	compress -f ${tmpfile}
	echo "end compress" >>$logfile
	mv -f ${tmpfile}".Z"  ${outputfile}".Z"
	echo "mv -f "${tmpfile}".Z  "${outputfile}".Z" >>$logfile
        break;;
2)
	echo "start to compress "${tmpfile} >>$logfile
	gzip -f ${tmpfile}
	echo "end compress" >>$logfile
	mv -f ${tmpfile}".gz"  ${outputfile}".gz"
	echo "mv -f "${tmpfile}".gz  "${outputfile}".gz" >>$logfile
        break;;
esac
echo "finish job!" >>$logfile

